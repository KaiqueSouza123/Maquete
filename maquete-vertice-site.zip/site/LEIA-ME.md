# Vértice Residence — maquete 3D (site)

Site estático: não precisa de build. Basta publicar a pasta inteira.

## Arquivos
- `index.html` — página e estilos
- `app.js` — interface (unidades, lazer, interiores, estudo solar, proposta)
- `engine.js` — motor 3D (WebGL2), entorno real do Google, ponte iluminada
- `config.js` — **chave do Google, posição do terreno, ponte e WhatsApp**
- `assets/apartamento.glb` — apartamento decorado

## Publicar na Vercel
1. Crie um repositório no GitHub e envie esta pasta (Add file → Upload files).
2. Na Vercel: Add New → Project → importe o repositório → Framework Preset: **Other** → Deploy.
3. Copie o endereço gerado (ex.: `maquete-xyz.vercel.app`).

## Depois de publicar (segurança da chave)
No Google Cloud → APIs e serviços → Credenciais → sua chave → Restrições de aplicativo →
**Referenciadores HTTP**: adicione `https://SEU-DOMINIO.vercel.app/*`.

## Ajustar terreno e ponte
Abra o site com `?ajuste=1` no final do endereço:
1. Mover o terreno: clique no ponto do mapa onde fica o lote.
2. Gire a fachada para ficar de frente para o mar e a ponte.
3. Encaixar na altura do chão.
4 e 5. Marque o topo das duas torres da ponte (de noite as luzes seguem essas torres).
Clique em "Salvar neste navegador" e copie o texto da caixa para fixar em `config.js`.

Outros parâmetros de endereço: `?google=0` (sem entorno real), `?lat=..&lon=..&heading=..`.
