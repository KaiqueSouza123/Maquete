/* Vértice 3D — motor WebGL2 da maquete digital (empreendimento fictício) */
(function () {
'use strict';
var PI = Math.PI;

/* ---------------- utilidades ---------------- */
function hex(h) { var n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }
function mix3(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
function sstep(a, b, x) { var t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
function rng(seed) { var s = (seed >>> 0) || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
function hash2(x, z) { var h = Math.sin(x * 127.1 + z * 311.7) * 43758.5453; return h - Math.floor(h); }
function vnoise(x, z) {
  var xi = Math.floor(x), zi = Math.floor(z), xf = x - xi, zf = z - zi;
  var u = xf * xf * (3 - 2 * xf), v = zf * zf * (3 - 2 * zf);
  var a = hash2(xi, zi), b = hash2(xi + 1, zi), c = hash2(xi, zi + 1), d = hash2(xi + 1, zi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, z) { var s = 0, a = 0.5, f = 1; for (var i = 0; i < 5; i++) { s += a * vnoise(x * f, z * f); f *= 2.03; a *= 0.5; } return s / 0.97; }

/* ---------------- matrizes (coluna-maior) ---------------- */
var M4 = {
  mul: function (a, b) { var o = new Float32Array(16); for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) { var s = 0; for (var k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
  persp: function (fovy, asp, n, f) { var t = 1 / Math.tan(fovy / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = 2 * f * n / (n - f); return o; },
  ortho: function (l, r, b, t, n, f) { var o = new Float32Array(16); o[0] = 2 / (r - l); o[5] = 2 / (t - b); o[10] = -2 / (f - n); o[12] = -(r + l) / (r - l); o[13] = -(t + b) / (t - b); o[14] = -(f + n) / (f - n); o[15] = 1; return o; },
  lookAt: function (e, c, u) {
    var zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2], l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
    var xx = u[1] * zz - u[2] * zy, xy = u[2] * zx - u[0] * zz, xz = u[0] * zy - u[1] * zx; l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
    var yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
      -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1]);
  },
  inv: function (a) {
    var o = new Float32Array(16);
    var a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3], a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7], a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11], a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
    var b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10, b03 = a01 * a12 - a02 * a11, b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12, b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30, b08 = a20 * a33 - a23 * a30, b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;
    var det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06; if (!det) return o; det = 1 / det;
    o[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det; o[1] = (a02 * b10 - a01 * b11 - a03 * b09) * det; o[2] = (a31 * b05 - a32 * b04 + a33 * b03) * det; o[3] = (a22 * b04 - a21 * b05 - a23 * b03) * det;
    o[4] = (a12 * b08 - a10 * b11 - a13 * b07) * det; o[5] = (a00 * b11 - a02 * b08 + a03 * b07) * det; o[6] = (a32 * b02 - a30 * b05 - a33 * b01) * det; o[7] = (a20 * b05 - a22 * b02 + a23 * b01) * det;
    o[8] = (a10 * b10 - a11 * b08 + a13 * b06) * det; o[9] = (a01 * b08 - a00 * b10 - a03 * b06) * det; o[10] = (a30 * b04 - a31 * b02 + a33 * b00) * det; o[11] = (a21 * b02 - a20 * b04 - a23 * b00) * det;
    o[12] = (a11 * b07 - a10 * b09 - a12 * b06) * det; o[13] = (a00 * b09 - a01 * b07 + a02 * b06) * det; o[14] = (a31 * b01 - a30 * b03 - a32 * b00) * det; o[15] = (a20 * b03 - a21 * b01 + a22 * b00) * det;
    return o;
  },
  xf: function (m, x, y, z, w) { return [m[0] * x + m[4] * y + m[8] * z + m[12] * w, m[1] * x + m[5] * y + m[9] * z + m[13] * w, m[2] * x + m[6] * y + m[10] * z + m[14] * w, m[3] * x + m[7] * y + m[11] * z + m[15] * w]; }
};

/* ---------------- construtor de geometria ---------------- */
var M0 = [0, 0];
function Geo() { this.d = []; this.T = [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0]; this.S = []; }
Geo.prototype = {
  push: function () { this.S.push(this.T.slice()); return this; },
  pop: function () { this.T = this.S.pop(); return this; },
  tr: function (x, y, z) { var T = this.T; T[9] += T[0] * x + T[3] * y + T[6] * z; T[10] += T[1] * x + T[4] * y + T[7] * z; T[11] += T[2] * x + T[5] * y + T[8] * z; return this; },
  _rot: function (i, j, a) { var T = this.T, c = Math.cos(a), s = Math.sin(a); for (var k = 0; k < 3; k++) { var u = T[i * 3 + k], v = T[j * 3 + k]; T[i * 3 + k] = c * u + s * v; T[j * 3 + k] = -s * u + c * v; } return this; },
  rx: function (a) { return this._rot(1, 2, a); },
  ry: function (a) { return this._rot(2, 0, a); },
  rz: function (a) { return this._rot(0, 1, a); },
  P: function (x, y, z) { var T = this.T; return [T[9] + T[0] * x + T[3] * y + T[6] * z, T[10] + T[1] * x + T[4] * y + T[7] * z, T[11] + T[2] * x + T[5] * y + T[8] * z]; },
  N: function (x, y, z) { var T = this.T; return [T[0] * x + T[3] * y + T[6] * z, T[1] * x + T[4] * y + T[7] * z, T[2] * x + T[5] * y + T[8] * z]; },
  v: function (p, n, c, m) { this.d.push(p[0], p[1], p[2], n[0], n[1], n[2], c[0], c[1], c[2], m[0], m[1]); },
  quad: function (a, b, c, d, n, col, m) { this.v(a, n, col, m); this.v(b, n, col, m); this.v(c, n, col, m); this.v(a, n, col, m); this.v(c, n, col, m); this.v(d, n, col, m); },
  box: function (x0, y0, z0, x1, y1, z1, col, m) {
    m = m || M0; var g = this, p = function (x, y, z) { return g.P(x, y, z); };
    if (typeof col === 'string') col = hex(col);
    g.quad(p(x1, y0, z0), p(x1, y1, z0), p(x1, y1, z1), p(x1, y0, z1), g.N(1, 0, 0), col, m);
    g.quad(p(x0, y0, z1), p(x0, y1, z1), p(x0, y1, z0), p(x0, y0, z0), g.N(-1, 0, 0), col, m);
    g.quad(p(x0, y1, z0), p(x0, y1, z1), p(x1, y1, z1), p(x1, y1, z0), g.N(0, 1, 0), col, m);
    g.quad(p(x0, y0, z0), p(x1, y0, z0), p(x1, y0, z1), p(x0, y0, z1), g.N(0, -1, 0), col, m);
    g.quad(p(x0, y0, z1), p(x1, y0, z1), p(x1, y1, z1), p(x0, y1, z1), g.N(0, 0, 1), col, m);
    g.quad(p(x1, y0, z0), p(x0, y0, z0), p(x0, y1, z0), p(x1, y1, z0), g.N(0, 0, -1), col, m);
    return g;
  },
  rectY: function (x0, z0, x1, z1, y, col, m) { if (typeof col === 'string') col = hex(col); this.quad(this.P(x0, y, z0), this.P(x0, y, z1), this.P(x1, y, z1), this.P(x1, y, z0), this.N(0, 1, 0), col, m || M0); return this; },
  cyl: function (cx, y0, cz, r, h, col, seg, r2, m, caps) {
    seg = seg || 12; if (r2 == null) r2 = r; m = m || M0; if (typeof col === 'string') col = hex(col); if (caps == null) caps = true;
    var sl = (r - r2) / h;
    for (var i = 0; i < seg; i++) {
      var a0 = i / seg * 2 * PI, a1 = (i + 1) / seg * 2 * PI, c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
      var n0 = this.N(c0, sl, s0), n1 = this.N(c1, sl, s1);
      var p00 = this.P(cx + c0 * r, y0, cz + s0 * r), p10 = this.P(cx + c1 * r, y0, cz + s1 * r), p01 = this.P(cx + c0 * r2, y0 + h, cz + s0 * r2), p11 = this.P(cx + c1 * r2, y0 + h, cz + s1 * r2);
      this.v(p00, n0, col, m); this.v(p10, n1, col, m); this.v(p11, n1, col, m);
      this.v(p00, n0, col, m); this.v(p11, n1, col, m); this.v(p01, n0, col, m);
      if (caps) {
        var up = this.N(0, 1, 0), dn = this.N(0, -1, 0);
        if (r2 > 0) { this.v(this.P(cx, y0 + h, cz), up, col, m); this.v(p01, up, col, m); this.v(p11, up, col, m); }
        this.v(this.P(cx, y0, cz), dn, col, m); this.v(p10, dn, col, m); this.v(p00, dn, col, m);
      }
    }
    return this;
  },
  sphere: function (cx, cy, cz, r, col, seg, ring, sy, m) {
    seg = seg || 10; ring = ring || 7; sy = sy || 1; m = m || M0; if (typeof col === 'string') col = hex(col);
    var self = this;
    function pt(i, j) { var th = j / ring * PI, ph = i / seg * 2 * PI; var x = Math.sin(th) * Math.cos(ph), y = Math.cos(th), z = Math.sin(th) * Math.sin(ph); return { p: self.P(cx + x * r, cy + y * r * sy, cz + z * r), n: self.N(x, y / sy, z) }; }
    for (var j = 0; j < ring; j++) for (var i = 0; i < seg; i++) {
      var a = pt(i, j), b = pt(i + 1, j), c = pt(i + 1, j + 1), d = pt(i, j + 1);
      this.v(a.p, a.n, col, m); this.v(b.p, b.n, col, m); this.v(c.p, c.n, col, m);
      this.v(a.p, a.n, col, m); this.v(c.p, c.n, col, m); this.v(d.p, d.n, col, m);
    }
    return this;
  },
  gable: function (x0, y0, z0, x1, y1, z1, col, alongX) {
    if (typeof col === 'string') col = hex(col);
    var p = this.P.bind(this), m = M0;
    if (alongX) {
      var zm = (z0 + z1) / 2, hz = (z1 - z0) / 2, hh = y1 - y0, l = Math.hypot(hz, hh);
      this.quad(p(x0, y0, z1), p(x1, y0, z1), p(x1, y1, zm), p(x0, y1, zm), this.N(0, hz / l, hh / l), col, m);
      this.quad(p(x1, y0, z0), p(x0, y0, z0), p(x0, y1, zm), p(x1, y1, zm), this.N(0, hz / l, -hh / l), col, m);
      var nx = this.N(1, 0, 0), nnx = this.N(-1, 0, 0);
      this.v(p(x1, y0, z0), nx, col, m); this.v(p(x1, y1, zm), nx, col, m); this.v(p(x1, y0, z1), nx, col, m);
      this.v(p(x0, y0, z1), nnx, col, m); this.v(p(x0, y1, zm), nnx, col, m); this.v(p(x0, y0, z0), nnx, col, m);
    } else {
      var xm = (x0 + x1) / 2, hx = (x1 - x0) / 2, h2 = y1 - y0, l2 = Math.hypot(hx, h2);
      this.quad(p(x1, y0, z0), p(x1, y0, z1), p(xm, y1, z1), p(xm, y1, z0), this.N(h2 / l2, hx / l2, 0), col, m);
      this.quad(p(x0, y0, z1), p(x0, y0, z0), p(xm, y1, z0), p(xm, y1, z1), this.N(-h2 / l2, hx / l2, 0), col, m);
      var nz = this.N(0, 0, 1), nnz = this.N(0, 0, -1);
      this.v(p(x0, y0, z1), nz, col, m); this.v(p(x1, y0, z1), nz, col, m); this.v(p(xm, y1, z1), nz, col, m);
      this.v(p(x1, y0, z0), nnz, col, m); this.v(p(x0, y0, z0), nnz, col, m); this.v(p(xm, y1, z0), nnz, col, m);
    }
    return this;
  },
  array: function () { return new Float32Array(this.d); }
};

/* materiais: [emissivo, tipo]  tipo 0 difuso, 1 água, 2 vidro, 3 tela */
var GLASS = [0, 2], WATER = [0, 1], WOOD = [0, 4], TILE = [0, 5], GRASS = [0, 6], PAVE = [0, 7], FABRIC = [0, 8];
function EM(e) { return [e, 0]; }
function SCREEN(e) { return [e, 3]; }

/* ---------------- sol (NOAA simplificado) ---------------- */
var LAT = -27.6, LON = -48.55, TZ = -3;
function sunInfo(month, day, hour) {
  var dim = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], doy = day; for (var i = 0; i < month - 1; i++) doy += dim[i];
  var g = 2 * PI / 365 * (doy - 1 + (hour - 12) / 24);
  var eq = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
  var decl = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  var lat = LAT * PI / 180;
  var tst = hour * 60 + eq + 4 * LON - 60 * TZ;
  var ha = (tst / 4 - 180) * PI / 180;
  var cz = Math.sin(lat) * Math.sin(decl) + Math.cos(lat) * Math.cos(decl) * Math.cos(ha); cz = clamp(cz, -1, 1);
  var zen = Math.acos(cz), el = 90 - zen * 180 / PI;
  var X = (Math.sin(lat) * Math.cos(zen) - Math.sin(decl)) / (Math.cos(lat) * Math.sin(zen) || 1e-6);
  var t = Math.acos(clamp(X, -1, 1)) * 180 / PI;
  var az = ha > 0 ? (t + 180) % 360 : (540 - t) % 360;
  var cosH0 = Math.cos(90.833 * PI / 180) / (Math.cos(lat) * Math.cos(decl)) - Math.tan(lat) * Math.tan(decl);
  var h0 = Math.acos(clamp(cosH0, -1, 1)) * 180 / PI;
  var rise = (720 - 4 * (LON + h0) - eq) / 60 + TZ, set = (720 - 4 * (LON - h0) - eq) / 60 + TZ, noon = (720 - 4 * LON - eq) / 60 + TZ;
  var e = el * PI / 180, a = az * PI / 180;
  /* x = oeste→leste espelhado para que o leste fique à esquerda de quem olha para o sul; z = norte */
  var dir = [-Math.sin(a) * Math.cos(e), Math.sin(e), Math.cos(a) * Math.cos(e)];
  return { elev: el, az: az, dir: dir, rise: rise, set: set, noon: noon };
}

/* ======================================================================
   CONSTRUÇÃO DO EMPREENDIMENTO
   ====================================================================== */
var C = {
  graphite: hex('#3a3d42'), fin: hex('#25272b'), slab: hex('#cfcbc3'), glass: hex('#2a3846'), rail: hex('#8fb3c4'), frame: hex('#1c1e21'),
  warm: hex('#ffc46b'), stone: hex('#d8d1c4'), lawn: hex('#5f8f48'), hedge: hex('#3f6b34'), deck: hex('#a98563'), wood: hex('#7a5638'),
  white: hex('#f3f1ec'), water: hex('#2fa8d0'), asphalt: hex('#4d4e52'), side: hex('#aaa69d')
};
var TOWER = { G: 4.5, FH: 3, NF: 15, W: 22, D: 13, X: { A: -24, B: 24 } };
var UNITX = { '01': [-11, -3], '02': [1, 11] };
function floorBase(f) { return TOWER.G + (f - 1) * TOWER.FH; }

function terrainH(x, z) {
  var n = fbm(x * 0.0055 + 3.1, z * 0.0055 + 7.7);
  var m = sstep(-95, -230, z);
  m = Math.max(m, sstep(260, 430, Math.abs(x)) * 0.9 * sstep(160, -40, z));
  var dh = Math.hypot(x + 70, z + 160); m = Math.max(m, sstep(140, 45, dh) * 0.85);
  var h = m * (24 + 150 * n * n + 40 * n);
  if (z > 182) h = -4 * sstep(182, 215, z);
  return h;
}

function buildTerrain(g) {
  var x0 = -820, x1 = 820, z0 = -820, z1 = 560, st = 16;
  var nx = Math.round((x1 - x0) / st), nz = Math.round((z1 - z0) / st);
  var H = [], i, j;
  for (j = 0; j <= nz; j++) { H[j] = []; for (i = 0; i <= nx; i++) H[j][i] = terrainH(x0 + i * st, z0 + j * st); }
  var urban = hex('#55565a'), sand = hex('#d6c79d'), f1 = hex('#2b4527'), f2 = hex('#4a6a37'), rock = hex('#6a6d5c');
  function vert(i, j) {
    var x = x0 + i * st, z = z0 + j * st, h = H[j][i];
    var hl = H[j][Math.max(0, i - 1)], hr = H[j][Math.min(nx, i + 1)], hd = H[Math.max(0, j - 1)][i], hu = H[Math.min(nz, j + 1)][i];
    var n = [hl - hr, 2 * st, hd - hu], l = Math.hypot(n[0], n[1], n[2]); n = [n[0] / l, n[1] / l, n[2] / l];
    var c;
    if (z > 168 && h < 1.5) c = sand;
    else if (h < 0.6) c = mix3(urban, hex('#5d7048'), sstep(0.005, 0.35, h));
    else { var t = fbm(x * 0.02, z * 0.02); c = mix3(f1, f2, t); c = mix3(c, rock, sstep(120, 210, h) * 0.6); c = mix3(urban, c, sstep(0.6, 3, h)); }
    return { p: [x, h, z], n: n, c: c, m: (h >= 0.6 && !(z > 168 && h < 1.5)) ? GRASS : M0 };
  }
  for (j = 0; j < nz; j++) for (i = 0; i < nx; i++) {
    var a = vert(i, j), b = vert(i + 1, j), c2 = vert(i + 1, j + 1), d = vert(i, j + 1);
    g.v(a.p, a.n, a.c, a.m); g.v(d.p, d.n, d.c, d.m); g.v(c2.p, c2.n, c2.c, c2.m);
    g.v(a.p, a.n, a.c, a.m); g.v(c2.p, c2.n, c2.c, c2.m); g.v(b.p, b.n, b.c, b.m);
  }
  /* mar */
  g.rectY(-820, 190, 820, 560, -0.6, hex('#2a6d8c'), WATER);
}

function tree(g, x, z, s, r) {
  var h = (2.2 + r() * 1.5) * s;
  g.cyl(x, 0, z, 0.16 * s, h, '#5b4330', 6, 0.12 * s, M0, false);
  var c = mix3(hex('#3c6a2f'), hex('#5a8a3c'), r());
  g.sphere(x, h + 1.0 * s, z, 1.7 * s, c, 8, 6, 0.85);
  g.sphere(x + 0.7 * s, h + 0.4 * s, z + 0.4 * s, 1.1 * s, mix3(c, hex('#2f5527'), 0.4), 7, 5, 0.85);
  g.sphere(x - 0.6 * s, h + 0.6 * s, z - 0.5 * s, 1.0 * s, mix3(c, hex('#6f9a48'), 0.35), 7, 5, 0.85);
}

function car(g, x, z, rot, col) {
  g.push().tr(x, 0, z).ry(rot);
  g.box(-2.1, 0.32, -0.9, 2.1, 1.0, 0.9, col);
  g.box(-1.2, 1.0, -0.82, 1.0, 1.55, 0.82, '#1d2a35', GLASS);
  for (var i = 0; i < 4; i++) { var wx = i < 2 ? -1.35 : 1.35, wz = i % 2 ? 0.86 : -0.86; g.push().tr(wx, 0.34, wz).rx(PI / 2); g.cyl(0, -0.12, 0, 0.34, 0.24, '#151515', 8); g.pop(); }
  g.box(2.08, 0.6, -0.75, 2.12, 0.8, -0.45, '#fff3d0', EM(1.2)); g.box(2.08, 0.6, 0.45, 2.12, 0.8, 0.75, '#fff3d0', EM(1.2));
  g.pop();
}

function buildCity(g, opts) {
  opts = opts || {};
  var r = rng(1337);
  var XR = [], ZR = [], k;
  for (k = -5; k <= 4; k++) XR.push(k < 0 ? -51 + 92 * (k + 1) : 51 + 92 * k);
  XR.sort(function (a, b) { return a - b; });
  for (k = -6; k <= 2; k++) ZR.push(29 + 58 * k);
  var houseCols = ['#f1ede4', '#e9dccb', '#f3e6c9', '#dfe7e3', '#efd9cf', '#e6e0d3'].map(hex);
  var roofCols = ['#b5543b', '#a4472f', '#c0623f', '#8f3d2a', '#9b5a46'].map(hex);
  var bldCols = ['#e6e2da', '#cfcac0', '#9ea3a6', '#3d4045', '#b9a993', '#dfe3e6', '#5b6066'].map(hex);
  for (var xi = 0; xi < XR.length - 1; xi++) for (var zi = 0; zi < ZR.length - 1; zi++) {
    var bx0 = XR[xi] + 5, bx1 = XR[xi + 1] - 5, bz0 = ZR[zi] + 5, bz1 = ZR[zi + 1] - 5;
    var site = bx0 < 0 && bx1 > 0 && bz0 < 0 && bz1 > 0;
    var hmax = Math.max(terrainH(bx0, bz0), terrainH(bx1, bz0), terrainH(bx0, bz1), terrainH(bx1, bz1), terrainH((bx0 + bx1) / 2, (bz0 + bz1) / 2));
    if (hmax > 0.5) continue;
    g.box(bx0, 0, bz0, bx1, 0.15, bz1, C.side, PAVE);
    if (site) continue;
    var dist = Math.hypot((bx0 + bx1) / 2, (bz0 + bz1) / 2);
    var beach = bz1 > 120;
    var near = dist < 185, pTower = near ? 0 : (beach ? 0.55 : (dist < 300 ? 0.14 : 0.06));
    var mid = (bz0 + bz1) / 2;
    var rows = [[bz0 + 1.5, mid - 0.5], [mid + 0.5, bz1 - 1.5]];
    for (var ri = 0; ri < 2; ri++) {
      var rz0 = rows[ri][0], rz1 = rows[ri][1], x = bx0 + 1.5;
      while (x < bx1 - 5) {
        var w = 9 + r() * 14; if (x + w > bx1 - 1.5) w = bx1 - 1.5 - x; if (w < 6) break;
        var x0 = x + 0.8, x1 = x + w - 0.8, q = r();
        if (q < pTower) {
          var h = 22 + r() * (beach ? 55 : 38), col = bldCols[(r() * bldCols.length) | 0];
          var z0 = rz0 + 1, z1 = rz1 - 1;
          g.box(x0, 0.15, z0, x1, h, z1, col);
          for (var y = 3.5; y < h - 2; y += 3) {
            var lit = r() < 0.22;
            g.box(x0 - 0.06, y, z0 - 0.06, x1 + 0.06, y + 1.4, z1 + 0.06, lit ? C.warm : C.glass, lit ? EM(0.55) : GLASS);
          }
          g.box(x0 + 1, h, z0 + 1, Math.min(x1 - 1, x0 + 5), h + 2.2, Math.min(z1 - 1, z0 + 4), col);
        } else if (q < pTower + 0.3) {
          var h2 = 6 + r() * (near ? 6 : 12), col2 = bldCols[(r() * bldCols.length) | 0];
          g.box(x0, 0.15, rz0 + 1.5, x1, h2, rz1 - 1.5, col2);
          for (var y2 = 2.2; y2 < h2 - 1.5; y2 += 3) g.box(x0 - 0.05, y2, rz0 + 1.45, x1 + 0.05, y2 + 1.2, rz1 - 1.45, C.glass, r() < 0.2 ? EM(0.4) : GLASS);
        } else if (q < 0.9) {
          var hh = 3 + r() * 3.2, dz = 7 + r() * 5, zc = ri === 0 ? rz0 + 1 + dz / 2 + r() * 2 : rz1 - 1 - dz / 2 - r() * 2;
          var hz0 = zc - dz / 2, hz1 = zc + dz / 2, hcol = houseCols[(r() * houseCols.length) | 0];
          g.box(x0, 0.15, hz0, x1, hh, hz1, hcol);
          g.gable(x0 - 0.35, hh, hz0 - 0.35, x1 + 0.35, hh + 1.6 + r() * 1.2, hz1 + 0.35, roofCols[(r() * roofCols.length) | 0], (x1 - x0) > (hz1 - hz0));
          var fz = ri === 0 ? hz0 - 0.03 : hz1 + 0.03;
          g.box(x0 + 1, 1.1, fz - 0.02, x0 + 2.2, 2.3, fz + 0.02, C.glass, r() < 0.3 ? EM(0.5) : GLASS);
          if (x1 - x0 > 6) g.box(x1 - 2.2, 1.1, fz - 0.02, x1 - 1, 2.3, fz + 0.02, C.glass, GLASS);
          if (r() < 0.6) tree(g, (x0 + x1) / 2 + (r() - 0.5) * 3, ri === 0 ? rz1 - 2 : rz0 + 2, 0.8, r);
        } else {
          tree(g, (x0 + x1) / 2, (rz0 + rz1) / 2, 1.1, r);
        }
        x += w;
      }
    }
  }
  /* faixa da rua principal e calçadas arborizadas */
  for (var lx = -400; lx < 400; lx += 7) g.box(lx, 0.02, 28.9, lx + 3.2, 0.05, 29.1, '#e8e4d8');
  for (var lx2 = -400; lx2 < 400; lx2 += 7) g.box(51 - 0.1, 0.02, lx2 * 0.5, 51 + 0.1, 0.05, lx2 * 0.5 + 1.6, '#e8e4d8');
  var carCols = ['#c8ccd0', '#1f2328', '#8a1f22', '#f2f2f0', '#2b4c7e', '#6b6f73'].map(hex);
  for (var ci = 0; ci < 16; ci++) { var cx = -180 + ci * 23 + r() * 8; car(g, cx, ci % 2 ? 26.6 : 31.4, ci % 2 ? 0 : PI, carCols[ci % carCols.length]); }
}

/* ---------------- torre ---------------- */
function buildTower(g, name, available, picks, glow) {
  var ox = TOWER.X[name], G = TOWER.G, FH = TOWER.FH, NF = TOWER.NF, top = G + NF * FH;
  var hw = TOWER.W / 2, hd = TOWER.D / 2;
  /* térreo */
  g.box(ox - hw + 0.8, 0.25, -hd + 0.8, ox + hw - 0.8, G, hd - 0.8, hex('#6b5843'), [0.55, 2]);
  for (var cx = -hw + 0.4; cx <= hw - 0.3; cx += 3.6) { g.box(ox + cx - 0.25, 0.25, hd - 0.55, ox + cx + 0.25, G, hd - 0.05, C.fin); g.box(ox + cx - 0.25, 0.25, -hd + 0.05, ox + cx + 0.25, G, -hd + 0.55, C.fin); }
  g.box(ox - 5, G - 0.55, hd, ox + 5, G - 0.2, hd + 4.2, C.fin);
  g.box(ox - 4.9, G - 0.6, hd + 0.1, ox + 4.9, G - 0.55, hd + 4.1, hex('#fff1cf'), EM(0.7));
  /* corpo */
  g.box(ox - hw + 0.1, G, -hd + 0.1, ox + hw - 0.1, top, hd - 0.1, C.graphite);
  for (var f = 0; f <= NF; f++) { var y = G + f * FH; g.box(ox - hw - 0.05, y - 0.16, -hd - 0.1, ox + hw + 0.05, y + 0.16, hd + 0.1, C.slab); }
  for (f = 1; f <= NF; f++) {
    var yb = floorBase(f);
    ['01', '02'].forEach(function (fin) {
      var ux = UNITX[fin], x0 = ox + ux[0], x1 = ox + ux[1], id = name + '-' + f + fin, lit = available.indexOf(id) >= 0;
      var gc = lit ? C.warm : C.glass, gm = lit ? EM(glow) : GLASS;
      /* fachada frontal: vidro + caixilhos */
      g.box(x0 + 0.3, yb + 0.16, hd - 0.12, x1 - 0.3, yb + FH - 0.16, hd - 0.04, gc, gm);
      for (var mx = x0 + 0.3; mx <= x1 - 0.2; mx += (x1 - x0 - 0.6) / 4) g.box(mx - 0.04, yb + 0.16, hd - 0.04, mx + 0.04, yb + FH - 0.16, hd + 0.02, C.frame);
      g.box(x0 + 0.3, yb + 2.32, hd - 0.04, x1 - 0.3, yb + 2.38, hd + 0.02, C.frame);
      /* sacada */
      g.box(x0 + 0.15, yb - 0.05, hd, x1 - 0.15, yb + 0.16, hd + 1.6, C.slab);
      g.box(x0 + 0.25, yb + 0.16, hd + 1.48, x1 - 0.25, yb + 1.12, hd + 1.53, C.rail, GLASS);
      g.box(x0 + 0.2, yb + 1.1, hd + 1.45, x1 - 0.2, yb + 1.16, hd + 1.56, C.frame);
      /* fundos */
      var bx = fin === '01' ? [-9, -5.5] : [3.2, 6.4, 9.4];
      bx.forEach(function (b) { g.box(ox + b - 1, yb + 0.7, -hd - 0.02, ox + b + 1, yb + 2.4, -hd + 0.05, gc, gm); });
      /* laterais */
      var sx = fin === '01' ? ox - hw : ox + hw, s = fin === '01' ? -1 : 1;
      [-3, 2.5].forEach(function (zc) { g.box(sx + (s < 0 ? -0.02 : -0.05), yb + 0.7, zc - 1, sx + (s < 0 ? 0.05 : 0.02), yb + 2.4, zc + 1, gc, gm); });
      if (lit) picks.push({ id: id, min: [x0, yb, -hd], max: [x1, yb + FH, hd + 1.6] });
    });
    /* núcleo */
    g.box(ox - 2.2, yb + 0.4, hd - 0.12, ox + 0.2, yb + FH - 0.4, hd - 0.03, C.glass, GLASS);
  }
  /* aletas verticais */
  [-hw, -3, 1, hw].forEach(function (fx) { g.box(ox + fx - 0.2, G, hd - 0.2, ox + fx + 0.2, top + 1.2, hd + 1.85, C.fin); });
  /* coroamento */
  g.box(ox - hw - 0.05, top, -hd - 0.1, ox + hw + 0.05, top + 1.2, hd + 0.1, C.graphite);
  g.box(ox - hw - 0.08, top + 1.0, -hd - 0.13, ox + hw + 0.08, top + 1.12, hd + 0.13, hex('#eaf6c8'), EM(0.9));
  g.box(ox - 7, top, -4.5, ox + 4, top + 4.2, 4.5, C.graphite);
  g.box(ox - 6.9, top + 3.4, 4.5, ox + 3.9, top + 3.6, 4.55, hex('#eaf6c8'), EM(0.6));
  g.box(ox + 5, top + 1.2, -3, ox + 8.5, top + 2.6, 0, hex('#8d9196'));
  g.cyl(ox - 1.5, top + 4.2, 0, 0.12, 6, '#9a9ea3', 6);
  g.sphere(ox - 1.5, top + 10.3, 0, 0.25, '#ff4b3a', 6, 4, 1, EM(2));
  return { top: top };
}

/* ---------------- área de lazer ---------------- */
function palm(g, x, z, h, lean, r) {
  var n = 9, ang = r() * 2 * PI, dx = Math.cos(ang) * lean, dz = Math.sin(ang) * lean;
  for (var i = 0; i < n; i++) {
    var t0 = i / n, t1 = (i + 1) / n;
    var ax = x + dx * t0 * t0, az = z + dz * t0 * t0;
    g.cyl(ax, h * t0, az, 0.24 - 0.09 * t0, h / n + 0.05, i % 2 ? '#8a7356' : '#7a644a', 7, 0.22 - 0.09 * t1, M0, false);
  }
  var tx = x + dx, tz = z + dz, ty = h;
  for (var k = 0; k < 10; k++) {
    g.push().tr(tx, ty, tz).ry(k / 10 * 2 * PI + r() * 0.3).rx(-0.35 - r() * 0.2);
    var L = 1.05, w = 0.38, col = mix3(hex('#3f7a35'), hex('#5f9a45'), r());
    for (var s = 0; s < 4; s++) {
      var ww = w * (1 - s * 0.2);
      g.box(-ww, -0.03, 0, ww, 0.03, L, col);
      g.tr(0, 0, L).rx(0.32);
    }
    g.pop();
  }
  for (var c = 0; c < 4; c++) g.sphere(tx + Math.cos(c * 1.7) * 0.25, ty - 0.25, tz + Math.sin(c * 1.7) * 0.25, 0.13, '#6b5a2e', 6, 4);
  return [tx, ty, tz];
}

function lounger(g, x, z, rot) {
  g.push().tr(x, 0.04, z).ry(rot);
  g.box(-0.35, 0.18, -0.95, 0.35, 0.3, 0.95, C.white);
  g.box(-0.33, 0.3, -0.3, 0.33, 0.38, 0.93, hex('#e9e1cf'));
  g.push().tr(0, 0.3, -0.3).rx(0.9); g.box(-0.33, 0, -0.75, 0.33, 0.08, 0, hex('#e9e1cf')); g.pop();
  [[-0.3, -0.85], [0.3, -0.85], [-0.3, 0.85], [0.3, 0.85]].forEach(function (p) { g.box(p[0] - 0.03, 0, p[1] - 0.03, p[0] + 0.03, 0.18, p[1] + 0.03, '#9a9a9a'); });
  g.pop();
}
function umbrella(g, x, z, col) { g.cyl(x, 0, z, 0.04, 2.5, '#d8d2c4', 6); g.cyl(x, 2.1, z, 1.5, 0.45, col || '#efe5cf', 10, 0.05); g.cyl(x, 0, z, 0.3, 0.1, '#888', 8); }
function chair(g, x, z, rot, col) {
  g.push().tr(x, 0, z).ry(rot);
  g.box(-0.23, 0.42, -0.23, 0.23, 0.47, 0.23, col);
  g.box(-0.23, 0.47, -0.25, 0.23, 0.92, -0.2, col);
  [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]].forEach(function (p) { g.box(p[0] - 0.02, 0, p[1] - 0.02, p[0] + 0.02, 0.42, p[1] + 0.02, '#2a2a2a'); });
  g.pop();
}
function armchair(g, x, z, rot, col) {
  g.push().tr(x, 0, z).ry(rot);
  g.box(-0.42, 0.05, -0.4, 0.42, 0.4, 0.4, '#6f5338');
  g.box(-0.36, 0.4, -0.34, 0.36, 0.5, 0.38, col);
  g.box(-0.42, 0.4, -0.4, 0.42, 0.85, -0.25, col);
  g.box(-0.42, 0.4, -0.4, -0.32, 0.62, 0.4, '#6f5338'); g.box(0.32, 0.4, -0.4, 0.42, 0.62, 0.4, '#6f5338');
  g.pop();
}
function tableRect(g, x, z, w, d, h, top, leg) {
  g.box(x - w / 2, h - 0.05, z - d / 2, x + w / 2, h, z + d / 2, top);
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (s) { var lx = x + s[0] * (w / 2 - 0.08), lz = z + s[1] * (d / 2 - 0.08); g.box(lx - 0.035, 0, lz - 0.035, lx + 0.035, h - 0.05, lz + 0.035, leg || top); });
}
function tableRound(g, x, z, r, h, top) { g.cyl(x, h - 0.04, z, r, 0.04, top, 16); g.cyl(x, 0, z, 0.04, h - 0.04, '#333', 6); g.cyl(x, 0, z, 0.25, 0.03, '#333', 10); }
function plant(g, x, z, s, y0) { y0 = y0 || 0; g.cyl(x, y0, z, 0.22 * s, 0.45 * s, '#c9b9a3', 10, 0.18 * s); g.sphere(x, y0 + 0.75 * s, z, 0.38 * s, '#4f7f3f', 8, 6, 1.1); g.sphere(x + 0.15 * s, y0 + 1.0 * s, z - 0.1 * s, 0.25 * s, '#5f9348', 7, 5); }

function person(g, x, y, z, rot, shirt, pants, skin, sc) {
  sc = sc || 1; var k = sc;
  g.push().tr(x, y, z).ry(rot);
  g.box(-0.16 * k, 0, -0.08 * k, -0.03 * k, 0.84 * k, 0.07 * k, pants, FABRIC); g.box(0.03 * k, 0, -0.08 * k, 0.16 * k, 0.84 * k, 0.07 * k, pants, FABRIC);
  g.box(-0.17 * k, 0, -0.07 * k, -0.02 * k, 0.07 * k, 0.15 * k, '#222'); g.box(0.02 * k, 0, -0.07 * k, 0.17 * k, 0.07 * k, 0.15 * k, '#222');
  g.box(-0.2 * k, 0.82 * k, -0.11 * k, 0.2 * k, 1.42 * k, 0.11 * k, shirt, FABRIC);
  g.box(-0.28 * k, 0.86 * k, -0.06 * k, -0.2 * k, 1.4 * k, 0.06 * k, shirt, FABRIC); g.box(0.2 * k, 0.86 * k, -0.06 * k, 0.28 * k, 1.4 * k, 0.06 * k, shirt, FABRIC);
  g.box(-0.27 * k, 0.74 * k, -0.05 * k, -0.21 * k, 0.88 * k, 0.05 * k, skin); g.box(0.21 * k, 0.74 * k, -0.05 * k, 0.27 * k, 0.88 * k, 0.05 * k, skin);
  g.cyl(0, 1.42 * k, 0, 0.05 * k, 0.08 * k, skin, 6);
  g.sphere(0, 1.6 * k, 0, 0.115 * k, skin, 8, 6, 1.1);
  g.sphere(0, 1.65 * k, -0.015 * k, 0.12 * k, hex(sc < 1 ? '#7a5230' : '#2b2018'), 8, 5, 0.75);
  g.pop();
}
function people(g) {
  var skins = ['#e2b896', '#c68e64', '#8d5a3b', '#f0caa8', '#a8714b'].map(hex);
  var shirts = ['#f2f2ef', '#2b5fb8', '#d6402f', '#1f2328', '#e8c547', '#5a8f6a', '#c9b8a0', '#7b4ea3'].map(hex);
  var pants = ['#2a3446', '#1d1d1f', '#c8b79a', '#4a4f57', '#6b8bb5'].map(hex);
  var P = [[-3.2, 0.28, 1.5, 0.4], [-2.4, 0.28, 1.2, -2.6], [2.6, 0.4, 9.2, 3.1], [-10.0, 0.29, 12.6, 1.0], [7.0, 0.36, -12.4, 3.0], [8.1, 0.36, -12.1, -2.8], [-7.3, 0.36, -11.4, 2.6], [-10.2, 0.36, -9.3, 1.2],
    [-30, 0.15, 22.2, 1.57], [12, 0.15, 23.7, -1.57], [34, 0.15, 22.4, 1.57], [-24, 0.28, 12.2, 0.1], [24.6, 0.28, 13.6, 3.0], [-23.2, 0.28, 12.4, -2.9]];
  P.forEach(function (p, i) { person(g, p[0], p[1], p[2], p[3], shirts[i % shirts.length], pants[i % pants.length], skins[i % skins.length]); });
  person(g, 9.9, 0.3, 13.0, 0.5, shirts[4], pants[4], skins[1], 0.62); person(g, 8.6, 0.3, 16.4, -1.0, shirts[2], pants[2], skins[3], 0.58);
}
function buildLeisure(g, roofs) {
  /* pisos */
  g.rectY(-13, -16, 13, 19, 0.26, C.stone, PAVE);
  g.rectY(-12.8, -1.2, 12.8, 18.6, 0.27, C.lawn, GRASS);
  g.rectY(-8, 0.6, 8, 10.6, 0.28, C.deck, WOOD);
  /* piscina */
  g.box(-6.4, 0.28, 2.1, 6.4, 0.4, 2.5, C.white); g.box(-6.4, 0.28, 8.5, 6.4, 0.4, 8.9, C.white);
  g.box(-6.4, 0.28, 2.5, -6.0, 0.4, 8.5, C.white); g.box(6.0, 0.28, 2.5, 6.4, 0.4, 8.5, C.white);
  g.rectY(-6, 2.5, 6, 8.5, 0.33, C.water, [0.12, 1]);
  g.rectY(3.6, 2.5, 6, 4.3, 0.345, hex('#9fdcec'), [0.12, 1]);
  for (var lx = -4.8; lx <= 4.8; lx += 2.4) lounger(g, lx, 9.75, PI);
  umbrella(g, -3.6, 9.9); umbrella(g, 1.2, 9.9); umbrella(g, 5.4, 9.9, '#d7f25b');
  var r = rng(77), palms = [[-9.3, 1.2, 7.5], [-9.8, 9.6, 8.5], [9.3, 1.4, 7.8], [9.6, 9.3, 7.0], [-11.6, 18, 9], [11.6, 18.2, 8.2], [-0.5, 0.0, 6.2], [12, -0.8, 6.5]];
  palms.forEach(function (p) { palm(g, p[0], p[1], p[2], 0.6 + r() * 0.9, r); });
  /* área de sombra (pergolado) */
  g.rectY(-12.6, 11, -6.4, 17.4, 0.29, hex('#b49573'), WOOD);
  [[-12.4, 11.2], [-6.6, 11.2], [-12.4, 17.2], [-6.6, 17.2]].forEach(function (p) { g.box(p[0] - 0.12, 0.27, p[1] - 0.12, p[0] + 0.12, 3.0, p[1] + 0.12, C.wood); });
  g.box(-12.6, 2.8, 11.1, -6.4, 3.05, 11.3, C.wood); g.box(-12.6, 2.8, 17.1, -6.4, 3.05, 17.3, C.wood);
  for (var sx = -12.5; sx <= -6.5; sx += 0.42) g.box(sx - 0.05, 3.05, 10.9, sx + 0.05, 3.25, 17.5, hex('#8a6545'));
  armchair(g, -11.2, 12.8, 0.6, hex('#e7dcc6')); armchair(g, -8.0, 12.8, -0.6, hex('#e7dcc6'));
  armchair(g, -11.2, 15.8, PI - 0.6, hex('#e7dcc6')); armchair(g, -8.0, 15.8, PI + 0.6, hex('#e7dcc6'));
  g.push().tr(0, 0.27, 0); tableRound(g, -9.6, 14.3, 0.55, 0.45, '#6f5338'); g.pop();
  chair(g, -12, 14.3, PI / 2, hex('#d7f25b'));
  plant(g, -6.9, 11.6, 1.1, 0.27); plant(g, -12.1, 17, 1.2, 0.27);
  /* área kids */
  g.rectY(6.2, 11, 12.8, 17.6, 0.29, hex('#e9734f'));
  g.rectY(6.8, 11.6, 9.8, 14.4, 0.3, hex('#f2c14e'));
  g.push().tr(0, 0.3, 0);
  [[7.4, 12.4], [8.8, 12.4], [7.4, 13.8], [8.8, 13.8]].forEach(function (p) { g.box(p[0] - 0.07, 0, p[1] - 0.07, p[0] + 0.07, 2.7, p[1] + 0.07, '#3d7fd6'); });
  g.box(7.3, 1.3, 12.3, 8.9, 1.42, 13.9, '#a8794e');
  g.gable(7.2, 2.7, 12.2, 9.0, 3.5, 14.0, '#e0453a', false);
  g.push().tr(8.9, 1.36, 13.1).rz(-0.55); g.box(0, -0.05, -0.38, 2.6, 0.03, 0.38, '#f5c542'); g.box(0, 0.03, -0.42, 2.6, 0.22, -0.36, '#f5c542'); g.box(0, 0.03, 0.36, 2.6, 0.22, 0.42, '#f5c542'); g.pop();
  for (var ly = 0.25; ly < 1.3; ly += 0.28) g.box(6.85, ly, 12.75, 7.3, ly + 0.05, 13.45, '#e9e4d8');
  g.box(6.82, 0, 12.7, 6.9, 1.4, 12.76, '#3d7fd6'); g.box(6.82, 0, 13.44, 6.9, 1.4, 13.5, '#3d7fd6');
  /* balanço */
  [[9.9, 15.4], [12.5, 15.4]].forEach(function (p) { g.push().tr(p[0], 0, p[1]).rz(0); g.box(-0.06, 0, -0.9, 0.06, 2.4, -0.78, '#e0453a'); g.box(-0.06, 0, 0.78, 0.06, 2.4, 0.9, '#e0453a'); g.pop(); });
  g.box(9.8, 2.3, 15.3, 12.6, 2.42, 15.5, '#e0453a');
  [10.6, 11.8].forEach(function (sx2) { g.box(sx2 - 0.25, 0.55, 15.2, sx2 + 0.25, 0.62, 15.6, '#2d2d2d'); g.box(sx2 - 0.22, 0.62, 15.38, sx2 - 0.2, 2.3, 15.42, '#9a9a9a'); g.box(sx2 + 0.2, 0.62, 15.38, sx2 + 0.22, 2.3, 15.42, '#9a9a9a'); });
  /* caixa de areia + gangorra */
  g.box(7.0, 0, 15.4, 9.2, 0.25, 15.55, '#a8794e'); g.box(7.0, 0, 17.0, 9.2, 0.25, 17.15, '#a8794e'); g.box(7.0, 0, 15.4, 7.15, 0.25, 17.15, '#a8794e'); g.box(9.05, 0, 15.4, 9.2, 0.25, 17.15, '#a8794e');
  g.rectY(7.15, 15.55, 9.05, 17.0, 0.18, '#e7d3a1');
  g.sphere(11.6, 0.65, 12.5, 0.3, '#5bbf6a', 8, 6); g.cyl(11.6, 0, 12.5, 0.08, 0.4, '#888', 6);
  g.pop();
  /* salão de jogos */
  var gx0 = -12.6, gx1 = -2.2, gz0 = -14.8, gz1 = -4.2, H = 3.4;
  g.box(gx0, 0.26, gz0, gx1, 0.36, gz1, hex('#a37b55'), WOOD);
  g.box(gx0, 0.36, gz0, gx1, H, gz0 + 0.25, hex('#e9e5dd'));
  g.box(gx0, 0.36, gz0, gx0 + 0.25, H, gz1, hex('#e9e5dd'));
  g.box(gx1 - 0.25, 0.36, gz0, gx1, H, gz1 - 2.2, hex('#e9e5dd'));
  for (var mz = gx0; mz <= gx1 + 0.01; mz += 1.3) g.box(mz - 0.05, 0.36, gz1 - 0.1, mz + 0.05, H, gz1, C.frame);
  g.box(gx0, H - 0.25, gz1 - 0.1, gx1, H, gz1, C.frame);
  g.box(gx0 + 0.4, 0.36, gz0 + 0.25, gx0 + 5.5, 2.6, gz0 + 0.28, hex('#2f5d4a'));
  roofs.box(gx0 - 0.3, H, gz0 - 0.3, gx1 + 0.3, H + 0.35, gz1 + 0.3, C.graphite);
  /* sinuca */
  var px = -8.6, pz = -10.2;
  g.box(px - 1.45, 0.36 + 0.62, pz - 0.82, px + 1.45, 0.36 + 0.8, pz + 0.82, hex('#5b3a24'));
  g.box(px - 1.3, 0.36 + 0.8, pz - 0.67, px + 1.3, 0.36 + 0.83, pz + 0.67, hex('#2f7a4a'));
  g.box(px - 1.45, 0.36 + 0.8, pz - 0.82, px + 1.45, 0.36 + 0.88, pz - 0.67, hex('#4a2f1d')); g.box(px - 1.45, 0.36 + 0.8, pz + 0.67, px + 1.45, 0.36 + 0.88, pz + 0.82, hex('#4a2f1d'));
  g.box(px - 1.45, 0.36 + 0.8, pz - 0.82, px - 1.3, 0.36 + 0.88, pz + 0.82, hex('#4a2f1d')); g.box(px + 1.3, 0.36 + 0.8, pz - 0.82, px + 1.45, 0.36 + 0.88, pz + 0.82, hex('#4a2f1d'));
  [[-1.2, -0.6], [1.2, -0.6], [-1.2, 0.6], [1.2, 0.6]].forEach(function (p) { g.box(px + p[0] - 0.1, 0.36, pz + p[1] - 0.1, px + p[0] + 0.1, 0.36 + 0.62, pz + p[1] + 0.1, hex('#4a2f1d')); });
  [[-1.3, -0.67], [0, -0.67], [1.3, -0.67], [-1.3, 0.67], [0, 0.67], [1.3, 0.67]].forEach(function (p) { g.cyl(px + p[0], 0.36 + 0.83, pz + p[1], 0.07, 0.02, '#0d0d0d', 8); });
  var bc = ['#f2f2f2', '#f2c14e', '#2b5fb8', '#d6402f', '#6a2f8f', '#f08a2b', '#2f8a4a', '#8a1f22', '#111'];
  bc.forEach(function (c, i) { var row = Math.floor(Math.sqrt(i * 2)); g.sphere(px + 0.55 + (i % 4) * 0.065, 0.36 + 0.86, pz - 0.1 + (i % 3) * 0.07 - (i > 5 ? 0.15 : 0), 0.03, c, 6, 4); });
  g.sphere(px - 0.7, 0.36 + 0.86, pz, 0.03, '#ffffff', 6, 4);
  g.push().tr(px - 0.2, 0.36 + 0.9, pz + 0.2).ry(0.3).rz(PI / 2 - 0.08); g.cyl(0, 0, 0, 0.012, 1.45, '#c99b62', 5); g.pop();
  for (var cq = 0; cq < 4; cq++) { g.box(gx0 + 0.28, 0.6, -9 + cq * 0.18, gx0 + 0.3, 2.1, -9 + cq * 0.18 + 0.03, '#c99b62'); }
  roofs.box(px - 1.0, 2.4, pz - 0.12, px + 1.0, 2.55, pz + 0.12, hex('#1d1d1d')); roofs.box(px - 0.95, 2.38, pz - 0.08, px + 0.95, 2.4, pz + 0.08, hex('#fff2d1'), EM(2.2));
  roofs.box(px - 0.02, 2.55, pz - 0.02, px + 0.02, H, pz + 0.02, '#222');
  /* pebolim */
  var fx = -4.5, fz = -7.4, fy = 0.36;
  g.box(fx - 0.62, fy + 0.62, fz - 0.4, fx + 0.62, fy + 0.92, fz + 0.4, hex('#6b4a2f'));
  g.box(fx - 0.55, fy + 0.86, fz - 0.33, fx + 0.55, fy + 0.88, fz + 0.33, hex('#2f8a4a'));
  [[-0.55, -0.4], [0.55, -0.4], [-0.55, 0.4], [0.55, 0.4]].forEach(function (p) { g.box(fx + p[0] - 0.05, fy, fz + p[1] - 0.05, fx + p[0] + 0.05, fy + 0.62, fz + p[1] + 0.05, hex('#4a2f1d')); });
  for (var ri2 = 0; ri2 < 8; ri2++) {
    var rx = fx - 0.48 + ri2 * 0.137, team = (ri2 === 0 || ri2 === 1 || ri2 === 3 || ri2 === 5) ? '#d6402f' : '#2b5fb8';
    g.push().tr(rx, fy + 0.9, fz).rx(PI / 2); g.cyl(0, -0.62, 0, 0.012, 1.24, '#c8c8c8', 5, null, M0, false); g.pop();
    g.push().tr(rx, fy + 0.9, fz + 0.66).rx(PI / 2); g.cyl(0, -0.06, 0, 0.03, 0.12, '#151515', 6); g.pop();
    g.push().tr(rx, fy + 0.9, fz - 0.66).rx(PI / 2); g.cyl(0, -0.06, 0, 0.03, 0.12, '#151515', 6); g.pop();
    var np = ri2 % 3 === 0 ? 2 : 3;
    for (var pp = 0; pp < np; pp++) { var pzz = fz - 0.2 + pp * (0.4 / (np - 1)); g.box(rx - 0.02, fy + 0.86, pzz - 0.025, rx + 0.02, fy + 0.98, pzz + 0.025, team); }
  }
  /* sofá + TV + alvo */
  g.push().tr(-6.5, 0.36, gz0 + 0.75); g.box(-1.3, 0, -0.45, 1.3, 0.42, 0.45, hex('#3d4a5c')); g.box(-1.3, 0.42, -0.45, 1.3, 0.85, -0.2, hex('#3d4a5c')); g.box(-1.3, 0.42, -0.45, -1.1, 0.62, 0.45, hex('#33404f')); g.box(1.1, 0.42, -0.45, 1.3, 0.62, 0.45, hex('#33404f')); g.pop();
  g.box(gx1 - 0.3, 1.3, -12.4, gx1 - 0.26, 2.3, -10.6, '#111');
  g.box(gx1 - 0.32, 1.35, -12.35, gx1 - 0.3, 2.25, -10.65, hex('#3a78c2'), SCREEN(0.9));
  g.push().tr(gx0 + 0.27, 1.7, -6.4).rz(-PI / 2); g.cyl(0, 0, 0, 0.25, 0.04, '#1a1a1a', 14); g.cyl(0, 0.04, 0, 0.17, 0.01, '#c43b2e', 14); g.cyl(0, 0.05, 0, 0.05, 0.01, '#2f8a4a', 10); g.pop();
  [[-3.2, -12.9], [-3.8, -13.5]].forEach(function (p) { g.cyl(p[0], 0.36, p[1], 0.18, 0.04, '#222', 10); g.cyl(p[0], 0.36, p[1], 0.03, 0.72, '#444', 6); g.cyl(p[0], 1.08, p[1], 0.18, 0.06, '#d7f25b', 10); });
  plant(g, gx1 - 0.7, gz1 - 2.8, 1.1, 0.36);
  /* espaço gourmet */
  var bx0 = 2.2, bx1 = 12.6, bz0 = -14.8, bz1 = -4.2;
  g.box(bx0, 0.26, bz0, bx1, 0.36, bz1, hex('#d6d0c4'), TILE);
  g.box(bx0, 0.36, bz0, bx1, H, bz0 + 0.25, hex('#e9e5dd'));
  g.box(bx1 - 0.25, 0.36, bz0, bx1, H, bz1, hex('#e9e5dd'));
  g.box(bx0, 0.36, bz0, bx0 + 0.25, H, bz1 - 2.2, hex('#e9e5dd'));
  for (var mz2 = bx0; mz2 <= bx1 + 0.01; mz2 += 1.3) g.box(mz2 - 0.05, 0.36, bz1 - 0.1, mz2 + 0.05, H, bz1, C.frame);
  g.box(bx0, H - 0.25, bz1 - 0.1, bx1, H, bz1, C.frame);
  roofs.box(bx0 - 0.3, H, bz0 - 0.3, bx1 + 0.3, H + 0.35, bz1 + 0.3, C.graphite);
  var brick = hex('#9a4f3a');
  g.box(6.2, 0.36, bz0 + 0.25, 8.8, 1.3, bz0 + 1.1, brick);
  g.box(6.4, 1.3, bz0 + 0.3, 8.6, 1.9, bz0 + 1.05, hex('#161616'));
  g.box(6.6, 1.3, bz0 + 0.5, 8.4, 1.36, bz0 + 1.0, hex('#ff7a2a'), EM(1.6));
  g.box(6.2, 1.9, bz0 + 0.25, 8.8, 2.7, bz0 + 1.2, brick);
  g.box(7.0, 2.7, bz0 + 0.25, 8.0, H, bz0 + 0.8, brick);
  [[2.5, 6.0], [9.0, 12.3]].forEach(function (s) {
    g.box(s[0], 0.36, bz0 + 0.25, s[1], 1.26, bz0 + 0.9, hex('#3a3d42'));
    g.box(s[0] - 0.02, 1.26, bz0 + 0.24, s[1] + 0.02, 1.31, bz0 + 0.93, hex('#ebe7df'));
    g.box(s[0], 1.9, bz0 + 0.25, s[1], 2.6, bz0 + 0.6, hex('#6f5338'));
  });
  g.box(3.4, 1.27, bz0 + 0.4, 4.2, 1.315, bz0 + 0.8, hex('#8b9196'));
  g.box(10.9, 0.36, bz0 + 0.95, 11.6, 1.2, bz0 + 1.55, hex('#c7cbcf'));
  /* TV */
  g.box(bx1 - 0.32, 1.45, -10.9, bx1 - 0.26, 2.55, -8.9, '#0d0d0d');
  g.box(bx1 - 0.34, 1.5, -10.85, bx1 - 0.32, 2.5, -8.95, hex('#2e8b57'), SCREEN(1.0));
  g.box(bx1 - 0.345, 1.98, -10.85, bx1 - 0.34, 2.02, -8.95, hex('#f4f4f4'), SCREEN(1.0));
  g.box(bx1 - 0.345, 1.5, -9.92, bx1 - 0.34, 2.5, -9.88, hex('#f4f4f4'), SCREEN(1.0));
  g.box(bx1 - 0.6, 0.36, -10.9, bx1 - 0.25, 0.9, -8.9, hex('#6f5338'));
  /* mesa */
  g.push().tr(0, 0.36, 0); tableRect(g, 6.6, -8.6, 3.4, 1.0, 0.76, hex('#8a6545'), hex('#3a2a1d'));
  for (var ch = 0; ch < 4; ch++) { chair(g, 5.4 + ch * 0.8, -9.5, 0, hex('#2f3237')); chair(g, 5.4 + ch * 0.8, -7.7, PI, hex('#2f3237')); }
  g.pop();
  [5.4, 6.6, 7.8].forEach(function (lx2) { roofs.box(lx2 - 0.01, 2.4, -8.61, lx2 + 0.01, H, -8.59, '#222'); roofs.sphere(lx2, 2.3, -8.6, 0.16, '#fff0c8', 8, 6, 1, EM(2.2)); });
  plant(g, bx0 + 0.6, bz1 - 2.8, 1.1, 0.36); plant(g, 11.8, -5.0, 1.0, 0.36);
}

function buildSite(g, roofs, google) {
  /* lote */
  if (google) g.box(-41, -6, -21, 41, 0.15, 24.5, C.side, PAVE);
  g.box(-38, 0.15, -18, 38, 0.26, 20.5, C.stone, PAVE);
  var r = rng(99);
  [[-38, -18, 38, -17.2], [-38, -18, -37.2, 20.5], [37.2, -18, 38, 20.5]].forEach(function (b) { g.box(b[0], 0.26, b[1], b[2], 1.4, b[3], C.hedge, GRASS); });
  [[-38, -29], [-19, -3], [3, 19], [29, 38]].forEach(function (s) { g.box(s[0], 0.26, 20.0, s[1], 0.85, 20.5, hex('#c9c3b6')); g.box(s[0], 0.85, 20.05, s[1], 1.35, 20.45, C.hedge, GRASS); });
  /* jardins frontais das torres */
  [-24, 24].forEach(function (ox) {
    g.rectY(ox - 12, 9.5, ox + 12, 19.5, 0.27, C.lawn, GRASS);
    g.rectY(ox - 3.5, 8.1, ox + 3.5, 20.5, 0.28, hex('#e4ddcf'), PAVE);
    [ox - 8, ox + 8].forEach(function (tx) { tree(g, tx, 15, 1.0, r); });
    plant(g, ox - 4.5, 10.5, 1.3, 0.27); plant(g, ox + 4.5, 10.5, 1.3, 0.27);
  });
  /* fundos */
  g.rectY(-37, -17, 37, -7.3, 0.27, hex('#6f8a5c'), GRASS);
  for (var px = -34; px <= 34; px += 2.8) { if (Math.abs(px) < 13.5) continue; g.rectY(px - 1.2, -16.6, px + 1.2, -11.6, 0.28, hex('#6a6b6e')); }
  /* calçada e árvores de rua */
  for (var tx = -44; tx <= 44; tx += 11) { tree(g, tx, 22.6, 0.9, r); }
  for (var lx = -42; lx <= 42; lx += 14) { g.cyl(lx, 0.15, 23.2, 0.07, 5.5, '#2a2c30', 6); g.box(lx - 0.5, 5.5, 23.0, lx + 0.5, 5.65, 23.4, '#2a2c30'); g.box(lx - 0.45, 5.45, 23.05, lx + 0.45, 5.5, 23.35, hex('#fff3d6'), EM(2)); }
  /* totem com nome */
  g.box(-1.6, 0.26, 19.2, 1.6, 2.2, 19.8, C.fin);
  g.box(-1.3, 1.5, 19.81, 1.3, 1.65, 19.83, hex('#d7f25b'), EM(0.8));
  buildLeisure(g, roofs);
  people(g);
}

/* ---------------- apartamentos ---------------- */
var IC = { wall: hex('#ece9e3'), wood: hex('#bb8c5c'), tile: hex('#d9d7d1'), deck: hex('#8f6b4a'), fabric: hex('#59616e'), white: hex('#f6f4ef'), dark: hex('#26272a'), stone: hex('#3a3a3c'), cab: hex('#e9e4da'), wd: hex('#6e4b32'), steel: hex('#c3c8cc') };
var WH = 2.7, WT = 0.12;
function wallAlong(g, axis, c, a0, a1, t, ops, col) {
  col = col || IC.wall; ops = (ops || []).slice().sort(function (p, q) { return p[0] - q[0]; });
  var segs = [], cur = a0;
  ops.forEach(function (o) { if (o[0] > cur) segs.push([cur, o[0], 0, WH]); var sill = o[2] || 0, head = o[3] || 2.1; if (sill > 0) segs.push([o[0], o[1], 0, sill]); if (head < WH) segs.push([o[0], o[1], head, WH]); cur = o[1]; });
  if (cur < a1) segs.push([cur, a1, 0, WH]);
  segs.forEach(function (s) { if (axis === 'x') g.box(s[0], s[2], c - t / 2, s[1], s[3], c + t / 2, col); else g.box(c - t / 2, s[2], s[0], c + t / 2, s[3], s[1], col); });
  ops.forEach(function (o) {
    if (!o[4]) return; var sill = o[2] || 0, head = o[3] || 2.1, n = Math.max(1, Math.round((o[1] - o[0]) / 1.3));
    for (var i = 0; i <= n; i++) { var a = o[0] + (o[1] - o[0]) * i / n; if (axis === 'x') g.box(a - 0.03, sill, c - 0.03, a + 0.03, head, c + 0.03, IC.dark); else g.box(c - 0.03, sill, a - 0.03, c + 0.03, head, a + 0.03, IC.dark); }
    if (axis === 'x') { g.box(o[0], head - 0.04, c - 0.03, o[1], head, c + 0.03, IC.dark); g.box(o[0], sill, c - 0.04, o[1], sill + 0.03, c + 0.04, IC.dark); }
    else { g.box(c - 0.03, head - 0.04, o[0], c + 0.03, head, o[1], IC.dark); g.box(c - 0.04, sill, o[0], c + 0.04, sill + 0.03, o[1], IC.dark); }
  });
}
function F(g, x, z, rot, fn) { g.push().tr(x, 0, z).ry(rot); fn(g); g.pop(); }
var furn = {
  sofa: function (g, L, col) { col = col || IC.fabric; var hl = L / 2; g.box(-hl, 0.08, -0.45, hl, 0.42, 0.45, col, FABRIC); g.box(-hl, 0.42, -0.45, hl, 0.86, -0.22, col, FABRIC); g.box(-hl, 0.42, -0.45, -hl + 0.18, 0.64, 0.45, col, FABRIC); g.box(hl - 0.18, 0.42, -0.45, hl, 0.64, 0.45, col, FABRIC); var c2 = mix3(col, [1, 1, 1], 0.12); g.box(-hl + 0.2, 0.42, -0.22, -0.02, 0.5, 0.42, c2, FABRIC); g.box(0.02, 0.42, -0.22, hl - 0.2, 0.5, 0.42, c2, FABRIC); g.box(-hl + 0.3, 0.5, -0.22, -hl + 0.7, 0.8, -0.1, hex('#d7f25b')); for (var i = -1; i <= 1; i += 2) g.box(i * (hl - 0.1) - 0.03, 0, -0.4, i * (hl - 0.1) + 0.03, 0.08, 0.4, IC.dark); },
  rug: function (g, w, d, col) { g.box(-w / 2, 0.005, -d / 2, w / 2, 0.02, d / 2, col || hex('#cfc4b2'), FABRIC); },
  coffee: function (g) { g.box(-0.55, 0.32, -0.32, 0.55, 0.38, 0.32, hex('#8a6545')); g.box(-0.5, 0, -0.27, 0.5, 0.32, 0.27, IC.dark); g.box(-0.1, 0.38, -0.1, 0.1, 0.5, 0.1, hex('#d9cbb5')); },
  tv: function (g, L) { g.box(-L / 2, 0.25, -0.22, L / 2, 0.6, 0.22, hex('#7a5a3f')); g.box(-0.8, 1.0, -0.25, 0.8, 1.9, -0.2, IC.dark); g.box(-0.76, 1.04, -0.2, 0.76, 1.86, -0.19, hex('#284d78'), SCREEN(0.7)); },
  bed: function (g, w, l, duvet) { var hw = w / 2; g.box(-hw - 0.05, 0.05, -l / 2, hw + 0.05, 0.32, l / 2, hex('#cbbfae')); g.box(-hw, 0.32, -l / 2 + 0.05, hw, 0.56, l / 2, IC.white); g.box(-hw - 0.02, 0.46, -l / 2 + 0.65, hw + 0.02, 0.6, l / 2 + 0.02, duvet || hex('#8fa3b8'), FABRIC); var pw = w > 1.2 ? 2 : 1; for (var i = 0; i < pw; i++) { var px = pw === 2 ? (i ? 0.38 : -0.38) : 0; g.box(px - 0.32, 0.56, -l / 2 + 0.12, px + 0.32, 0.72, -l / 2 + 0.48, IC.white); } g.box(-hw - 0.12, 0, -l / 2 - 0.08, hw + 0.12, 1.15, -l / 2, hex('#6d5a47')); },
  nightstand: function (g) { g.box(-0.24, 0, -0.2, 0.24, 0.5, 0.2, IC.wd); g.cyl(0, 0.5, 0, 0.06, 0.25, '#ccc', 6); g.cyl(0, 0.72, 0, 0.16, 0.2, '#fff2d6', 10, 0.11, EM(1.6)); },
  wardrobe: function (g, L) { g.box(-L / 2, 0, -0.3, L / 2, 2.4, 0.3, IC.cab); var n = Math.round(L / 0.6); for (var i = 1; i < n; i++) { var x = -L / 2 + L * i / n; g.box(x - 0.006, 0.05, 0.3, x + 0.006, 2.35, 0.31, hex('#b9b2a5')); } },
  kitchen: function (g, L, sinkX, cookX) { g.box(-L / 2, 0, -0.3, L / 2, 0.86, 0.3, IC.cab); g.box(-L / 2 - 0.02, 0.86, -0.31, L / 2 + 0.02, 0.9, 0.31, IC.stone); g.box(sinkX - 0.3, 0.88, -0.2, sinkX + 0.3, 0.905, 0.2, IC.steel); g.cyl(sinkX, 0.9, -0.25, 0.02, 0.3, '#bbb', 6); g.box(cookX - 0.32, 0.9, -0.26, cookX + 0.32, 0.915, 0.26, hex('#111')); g.box(-L / 2, 1.5, -0.3, L / 2, 2.25, 0.05, IC.wd); g.box(cookX - 0.35, 1.35, -0.3, cookX + 0.35, 1.5, 0.15, IC.steel); },
  fridge: function (g) { g.box(-0.37, 0, -0.35, 0.37, 1.86, 0.35, IC.steel); g.box(-0.3, 0.9, 0.35, -0.27, 1.5, 0.38, hex('#888')); g.box(-0.37, 1.18, 0.35, 0.37, 1.2, 0.36, hex('#999')); },
  island: function (g, L) { g.box(-L / 2, 0, -0.3, L / 2, 0.9, 0.3, IC.wd); g.box(-L / 2 - 0.05, 0.9, -0.33, L / 2 + 0.05, 0.94, 0.62, IC.stone); },
  stool: function (g) { g.cyl(0, 0, 0, 0.2, 0.03, '#222', 10); g.cyl(0, 0, 0, 0.03, 0.66, '#333', 6); g.cyl(0, 0.66, 0, 0.19, 0.07, '#d7f25b', 12); },
  toilet: function (g) { g.box(-0.18, 0, -0.33, 0.18, 0.75, -0.18, IC.white); g.cyl(0, 0, 0.0, 0.2, 0.4, IC.white, 12, 0.19); g.cyl(0, 0.4, 0, 0.21, 0.03, '#e8e8e8', 12); },
  vanity: function (g, L) { g.box(-L / 2, 0.15, -0.25, L / 2, 0.85, 0.25, IC.wd); g.box(-L / 2, 0.85, -0.25, L / 2, 0.88, 0.25, IC.white); g.cyl(0, 0.88, 0, 0.17, 0.12, IC.white, 12); g.box(-L / 2 + 0.05, 1.1, -0.26, L / 2 - 0.05, 1.9, -0.24, hex('#b9c9d3'), GLASS); },
  shower: function (g, w, d) { g.box(-w / 2, 0, -d / 2, w / 2, 0.04, d / 2, IC.white); g.box(-w / 2, 0.04, d / 2 - 0.02, w / 2 - 0.3, 2.0, d / 2, hex('#cfe2ea'), GLASS); g.cyl(w / 2 - 0.2, 1.95, -d / 2 + 0.2, 0.1, 0.03, '#bbb', 10); g.box(w / 2 - 0.22, 1.98, -d / 2 + 0.02, w / 2 - 0.18, 2.1, -d / 2 + 0.22, '#bbb'); },
  desk: function (g, L) { g.box(-L / 2, 0.72, -0.3, L / 2, 0.76, 0.3, hex('#d9cbb5')); g.box(-L / 2, 0, -0.28, -L / 2 + 0.04, 0.72, 0.28, IC.dark); g.box(L / 2 - 0.04, 0, -0.28, L / 2, 0.72, 0.28, IC.dark); g.box(-0.3, 0.9, -0.22, 0.3, 1.25, -0.2, IC.dark); g.box(-0.28, 0.92, -0.2, 0.28, 1.23, -0.19, hex('#3c6fb0'), SCREEN(0.8)); g.box(-0.03, 0.76, -0.22, 0.03, 0.9, -0.2, IC.dark); },
  table: function (g, w, d) { tableRect(g, 0, 0, w, d, 0.75, hex('#8a6545'), IC.dark); },
  plant: function (g, s) { plant(g, 0, 0, s); },
  chair: function (g, col) { chair(g, 0, 0, 0, col || hex('#2f3237')); },
  grill: function (g) { g.box(-0.5, 0, -0.25, 0.5, 0.85, 0.25, hex('#9a4f3a')); g.box(-0.45, 0.85, -0.22, 0.45, 0.9, 0.22, hex('#111')); g.box(-0.5, 1.35, -0.25, 0.5, 1.9, 0.25, hex('#9a4f3a')); g.box(-0.2, 1.9, -0.2, 0.2, 2.6, 0.1, hex('#9a4f3a')); }
};
function balcony(g, W, D, depth) {
  g.box(0, -0.14, D, W, 0, D + depth, IC.deck, WOOD);
  g.box(0.05, 0, D + depth - 0.06, W - 0.05, 1.08, D + depth - 0.02, hex('#9ec3d3'), GLASS);
  g.box(0, 1.06, D + depth - 0.09, W, 1.12, D + depth + 0.01, IC.dark);
  g.box(-0.1, 0, D, 0.05, 1.12, D + depth, IC.dark); g.box(W - 0.05, 0, D, W + 0.1, 1.12, D + depth, IC.dark);
}
function aptShell(g, W, D) {
  g.box(-0.4, -0.5, -0.4, W + 0.4, -0.12, D + 1.8, hex('#bdb8af'));
  g.box(-0.4, -0.5, -0.4, W + 0.4, -0.45, D + 1.8, hex('#9d988f'));
  /* aletas da fachada */
  g.box(-0.35, -0.5, D - 0.1, -0.08, WH + 0.25, D + 1.85, hex('#25272b'));
  g.box(W + 0.08, -0.5, D - 0.1, W + 0.35, WH + 0.25, D + 1.85, hex('#25272b'));
}
function floorRect(g, x0, z0, x1, z1, col) { g.box(x0, -0.12, z0, x1, 0, z1, col, col === IC.wood ? WOOD : col === IC.tile ? TILE : M0); }

function buildApt1(g) {
  var W = 8, D = 6.5; aptShell(g, W, D);
  floorRect(g, 0, 0, 4.6, 2.7, IC.tile); floorRect(g, 0, 2.7, 4.6, D, IC.wood); floorRect(g, 4.6, 2.8, W, D, IC.wood); floorRect(g, 4.6, 0, 5.9, 2.8, IC.wood); floorRect(g, 5.9, 0, W, 2.8, IC.tile);
  balcony(g, W, D, 1.6);
  wallAlong(g, 'x', 0, 0, W, 0.2, [[4.8, 5.7, 0, 2.1]]);
  wallAlong(g, 'z', 0, 0, D, 0.2, [[0.6, 2.0, 1.1, 2.1, 1]]);
  wallAlong(g, 'z', W, 0, D, 0.2, [[3.7, 5.6, 0.9, 2.2, 1], [0.9, 1.7, 1.5, 2.1, 1]]);
  wallAlong(g, 'x', D, 0, W, 0.16, [[0.3, 4.3, 0, 2.35, 1], [5.0, 7.6, 0, 2.35, 1]]);
  wallAlong(g, 'z', 4.6, 0, D, WT, [[0.9, 2.6, 0, 2.1]]);
  wallAlong(g, 'x', 2.8, 4.6, W, WT, [[4.8, 5.7, 0, 2.1]]);
  wallAlong(g, 'z', 5.9, 0, 2.8, WT, [[1.6, 2.5, 0, 2.1]]);
  /* sala */
  F(g, 2.0, 4.9, 0, function (g) { furn.rug(g, 2.4, 1.9); });
  F(g, 3.6, 4.9, -PI / 2, function (g) { furn.sofa(g, 2.2); });
  F(g, 2.1, 4.9, PI / 2, function (g) { furn.coffee(g); });
  F(g, 0.32, 4.9, PI / 2, function (g) { furn.tv(g, 1.9); });
  F(g, 0.5, 6.1, 0, function (g) { furn.plant(g, 1.1); });
  /* cozinha integrada */
  F(g, 0.45, 0.48, 0, function (g) { furn.fridge(g); });
  F(g, 2.45, 0.4, 0, function (g) { furn.kitchen(g, 2.9, -0.5, 0.7); });
  F(g, 2.2, 2.35, PI, function (g) { furn.island(g, 2.4); });
  [1.5, 2.2, 2.9].forEach(function (x) { F(g, x, 3.15, 0, function (g) { furn.stool(g); }); });
  /* quarto */
  F(g, 6.9, 4.65, -PI / 2, function (g) { furn.bed(g, 1.6, 2.0); });
  F(g, 7.65, 3.6, -PI / 2, function (g) { furn.nightstand(g); });
  F(g, 7.65, 5.75, -PI / 2, function (g) { furn.nightstand(g); });
  F(g, 6.75, 3.2, 0, function (g) { furn.wardrobe(g, 1.9); });
  /* banheiro */
  F(g, 7.45, 0.55, 0, function (g) { furn.shower(g, 1.0, 0.95); });
  F(g, 7.62, 1.75, -PI / 2, function (g) { furn.toilet(g); });
  F(g, 6.4, 0.32, 0, function (g) { furn.vanity(g, 0.85); });
  /* sacada */
  F(g, 2.2, 7.3, 0, function (g) { tableRound(g, 0, 0, 0.32, 0.7, '#d9cbb5'); });
  F(g, 1.55, 7.3, PI / 2, function (g) { furn.chair(g, hex('#d7f25b')); });
  F(g, 2.85, 7.3, -PI / 2, function (g) { furn.chair(g, hex('#d7f25b')); });
  F(g, 7.4, 7.6, 0, function (g) { furn.plant(g, 1.2); });
  return { W: W, D: D };
}

function buildApt2(g) {
  var W = 10, D = 7; aptShell(g, W, D);
  floorRect(g, 0, 0, 5.2, 3.2, IC.tile); floorRect(g, 0, 3.2, 5.2, D, IC.wood); floorRect(g, 5.2, 2.5, W, D, IC.wood); floorRect(g, 5.2, 0, 7.9, 2.5, IC.wood); floorRect(g, 7.9, 0, W, 2.5, IC.tile); floorRect(g, 8.4, 3.5, W, 5.2, IC.tile);
  balcony(g, W, D, 1.6);
  wallAlong(g, 'x', 0, 0, W, 0.2, [[4.3, 5.1, 0, 2.1], [5.8, 7.2, 1.0, 2.1, 1]]);
  wallAlong(g, 'z', 0, 0, D, 0.2, [[3.9, 6.3, 0.6, 2.2, 1], [0.8, 2.2, 1.1, 2.1, 1]]);
  wallAlong(g, 'z', W, 0, D, 0.2, [[0.8, 1.7, 1.5, 2.1, 1], [3.9, 4.8, 1.5, 2.1, 1], [5.6, 6.6, 0.9, 2.2, 1]]);
  wallAlong(g, 'x', D, 0, W, 0.16, [[0.3, 5.0, 0, 2.35, 1], [5.6, 8.2, 0, 2.35, 1]]);
  wallAlong(g, 'z', 5.2, 0, 2.5, WT, []);
  wallAlong(g, 'z', 5.2, 3.5, D, WT, []);
  wallAlong(g, 'x', 2.5, 5.2, W, WT, [[6.5, 7.4, 0, 2.1], [8.6, 9.5, 0, 2.1]]);
  wallAlong(g, 'z', 7.9, 0, 2.5, WT, []);
  wallAlong(g, 'x', 3.5, 5.2, W, WT, [[5.5, 6.4, 0, 2.1]]);
  wallAlong(g, 'z', 8.4, 3.5, 5.2, WT, [[4.3, 5.1, 0, 2.1]]);
  wallAlong(g, 'x', 5.2, 8.4, W, WT, []);
  /* sala */
  F(g, 2.5, 5.2, 0, function (g) { furn.rug(g, 2.6, 2.2, hex('#c9bfae')); });
  F(g, 1.0, 5.2, PI / 2, function (g) { furn.sofa(g, 2.4, hex('#4c5563')); });
  F(g, 2.5, 5.2, PI / 2, function (g) { furn.coffee(g); });
  F(g, 4.85, 5.2, -PI / 2, function (g) { furn.tv(g, 2.0); });
  F(g, 4.7, 6.5, 0, function (g) { furn.plant(g, 1.2); });
  /* cozinha + bancada (link sala/cozinha) */
  F(g, 0.45, 0.48, 0, function (g) { furn.fridge(g); });
  F(g, 2.5, 0.4, 0, function (g) { furn.kitchen(g, 3.0, -0.6, 0.8); });
  F(g, 2.5, 2.75, PI, function (g) { furn.island(g, 3.0); });
  [1.5, 2.2, 2.9, 3.6].forEach(function (x) { F(g, x, 3.55, 0, function (g) { furn.stool(g); }); });
  /* suíte */
  F(g, 6.3, 5.3, PI / 2, function (g) { furn.bed(g, 1.6, 2.0, hex('#b9a38c')); });
  F(g, 5.55, 4.25, PI / 2, function (g) { furn.nightstand(g); });
  F(g, 5.55, 6.35, PI / 2, function (g) { furn.nightstand(g); });
  F(g, 9.65, 6.1, -PI / 2, function (g) { furn.wardrobe(g, 1.6); });
  F(g, 8.0, 6.4, -2.4, function (g) { armchair(g, 0, 0, 0, hex('#c9b8a0')); });
  /* banho da suíte */
  F(g, 9.45, 4.0, 0, function (g) { furn.shower(g, 1.0, 0.9); });
  F(g, 9.7, 4.85, -PI / 2, function (g) { furn.toilet(g); });
  F(g, 8.75, 4.9, PI / 2, function (g) { furn.vanity(g, 0.7); });
  /* quarto 2 / home office */
  F(g, 6.3, 0.55, 0, function (g) { furn.bed(g, 0.9, 1.9, hex('#d7a86e')); });
  F(g, 7.5, 1.6, -PI / 2, function (g) { furn.desk(g, 1.1); });
  F(g, 7.0, 1.6, PI / 2, function (g) { furn.chair(g, hex('#d7f25b')); });
  /* banheiro social */
  F(g, 9.45, 0.55, 0, function (g) { furn.shower(g, 1.0, 0.95); });
  F(g, 9.65, 1.85, -PI / 2, function (g) { furn.toilet(g); });
  F(g, 8.3, 0.4, 0, function (g) { furn.vanity(g, 0.7); });
  /* sacada gourmet */
  F(g, 9.0, 8.25, PI, function (g) { furn.grill(g); });
  F(g, 3.0, 7.8, 0, function (g) { furn.table(g, 1.2, 0.75); });
  F(g, 2.6, 7.3, 0, function (g) { furn.chair(g); }); F(g, 3.4, 7.3, 0, function (g) { furn.chair(g); });
  F(g, 2.6, 8.3, PI, function (g) { furn.chair(g); }); F(g, 3.4, 8.3, PI, function (g) { furn.chair(g); });
  F(g, 0.5, 8.2, 0, function (g) { furn.plant(g, 1.1); });
  return { W: W, D: D };
}

/* ======================================================================
   SHADERS
   ====================================================================== */
var GLN = 'float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}\n' +
  'float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hs(i),hs(i+vec2(1,0)),f.x),mix(hs(i+vec2(0,1)),hs(i+vec2(1,1)),f.x),f.y);}\n' +
  'float fb(vec2 p){float s=0.,a=.5;for(int i=0;i<5;i++){s+=a*vn(p);p*=2.03;a*=.5;}return s;}\n';
var ACES = 'vec3 aces(vec3 c){c=(c*(2.51*c+.03))/(c*(2.43*c+.59)+.14);return pow(clamp(c,0.,1.),vec3(1./2.2));}\n';
var VS = '#version 300 es\nlayout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec3 aC;layout(location=3) in vec2 aM;\n' +
  'uniform mat4 uVP,uLVP;uniform vec3 uOff;out vec3 vN,vC,vW;out vec2 vM;out vec4 vL;\n' +
  'void main(){vec3 p=aP+uOff;vW=p;vN=aN;vC=pow(aC,vec3(2.2));vM=aM;vL=uLVP*vec4(p,1.);gl_Position=uVP*vec4(p,1.);}';
var FS = '#version 300 es\nprecision highp float;precision highp sampler2DShadow;\n' +
  'in vec3 vN,vC,vW;in vec2 vM;in vec4 vL;\n' +
  'uniform vec3 uSun,uSunC,uSky,uGnd,uFogC,uEye,uZen,uHor;uniform float uFog,uEmis,uTime,uFade,uShOn,uTex,uHdr,uSMs;uniform sampler2DShadow uSh;\n' +
  'uniform vec3 uPLp[12];uniform vec3 uPLc[12];uniform int uPLn;out vec4 o;\n' + GLN + ACES +
  'vec3 sky(vec3 d){float t=clamp(d.y,0.,1.);vec3 c=mix(uHor,uZen,pow(t,.55));if(d.y<0.)c=mix(uHor,uGnd*1.6,clamp(-d.y*5.,0.,1.));float s=max(dot(d,uSun),0.);return c+uSunC*pow(s,300.)*2.;}\n' +
  'float shadow(vec3 N){vec3 p=vL.xyz/vL.w*.5+.5;if(p.x<0.||p.x>1.||p.y<0.||p.y>1.||p.z>1.)return 1.;float b=uTex*(1.5+2.5*(1.-abs(dot(N,uSun))));float s=0.;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=texture(uSh,vec3(p.xy+vec2(x,y)*1.5/uSMs,p.z-b));return s/9.;}\n' +
  'void main(){vec3 N=normalize(vN);vec3 V=normalize(uEye-vW);int K=int(floor(vM.y+.5));vec3 base=vC;float spec=.035,shin=24.;\n' +
  'vec3 a=abs(N);vec2 q=a.y>.5?vW.xz:(a.x>a.z?vW.zy:vW.xy);\n' +
  'if(K==1){float w=sin(vW.x*1.9+uTime*1.4)*.5+sin(vW.z*2.6-uTime*1.2)*.5+sin((vW.x+vW.z)*3.7+uTime*2.)*.3;N=normalize(N+vec3(w*.07,0.,w*.06));}\n' +
  'else if(K==4&&a.y>.5){float w=.19;float row=floor(q.y/w);float fy=fract(q.y/w);float off=hs(vec2(row,3.))*1.6;float L=1.5;float cx=floor((q.x+off)/L);float fx=fract((q.x+off)/L);float id=hs(vec2(row,cx));float gr=vn(vec2((q.x+off)*2.,q.y*55.+id*20.));base*=.8+.32*id;base*=.88+.24*gr;float e=min(min(fy,1.-fy)*w,min(fx,1.-fx)*L);base*=mix(.5,1.,smoothstep(0.,.005,e));spec=.14;shin=70.;}\n' +
  'else if(K==4){base*=.9+.2*vn(q*vec2(2.,30.));}\n' +
  'else if(K==5){float s=.6;vec2 g=fract(q/s);vec2 id=floor(q/s);float e=min(min(g.x,1.-g.x),min(g.y,1.-g.y))*s;base*=.94+.09*hs(id)+.04*vn(q*9.);base=mix(base*.78,base,smoothstep(0.,.004,e));spec=.28;shin=110.;}\n' +
  'else if(K==6){float n=fb(vW.xz*.35);float n2=vn(vW.xz*7.+vW.y*3.);base*=.7+.55*n;base*=.86+.26*n2;base=mix(base,base*vec3(1.15,1.08,.62),smoothstep(.55,.8,n)*.45);spec=0.;}\n' +
  'else if(K==7){vec2 s=vec2(.8,.4);vec2 qq=q/s;qq.x+=floor(qq.y)*.5;vec2 g=fract(qq);vec2 id=floor(qq);float e=min(min(g.x,1.-g.x)*s.x,min(g.y,1.-g.y)*s.y);base*=.9+.13*hs(id);base*=.93+.12*vn(q*3.);base=mix(base*.68,base,smoothstep(0.,.012,e));spec=.03;}\n' +
  'else if(K==8){base*=.9+.12*vn(q*45.)+.06*vn(q*3.);spec=0.;}\n' +
  'else if(K==0){base*=.95+.1*vn(q*.7)+.03*vn(q*9.);}\n' +
  'float nd=max(dot(N,uSun),0.);float sh=(nd>0.&&uShOn>.5)?shadow(N):1.;\n' +
  'vec3 amb=mix(uGnd,uSky,N.y*.5+.5);vec3 lp=vec3(0.);\n' +
  'for(int i=0;i<12;i++){if(i>=uPLn)break;vec3 dl=uPLp[i]-vW;float dd=dot(dl,dl);vec3 l=dl*inversesqrt(dd);lp+=uPLc[i]*(max(dot(N,l),0.)*.85+.15)/(dd+.6);}\n' +
  'vec3 col=base*(amb+uSunC*nd*sh+lp);vec3 H=normalize(uSun+V);col+=uSunC*sh*nd*spec*pow(max(dot(N,H),0.),shin);\n' +
  'if(K==1||K==2){vec3 R=reflect(-V,N);float fr=pow(1.-max(dot(N,V),0.),4.);vec3 rf=sky(R);float m=K==1?.25+.6*fr:.2+.7*fr;col=mix(col,rf*(K==2?.85:1.),m);col+=uSunC*sh*pow(max(dot(R,uSun),0.),K==1?200.:500.)*4.;}\n' +
  'col+=base*vM.x*uEmis;if(K==3)col=base*(.2+vM.x*1.4);\n' +
  'float d=length(vW-uEye);col=mix(col,uFogC,1.-exp(-d*uFog));\n' +
  'if(uHdr<.5)col=aces(col);o=vec4(col*uFade,1.);}';
var VSD = '#version 300 es\nlayout(location=0) in vec3 aP;uniform mat4 uLVP;uniform vec3 uOff;void main(){gl_Position=uLVP*vec4(aP+uOff,1.);}';
var FSD = '#version 300 es\nprecision mediump float;void main(){}';
var VSS = '#version 300 es\nout vec2 vP;void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2))*2.-1.;vP=p;gl_Position=vec4(p,.9999,1.);}';
var FSS = '#version 300 es\nprecision highp float;in vec2 vP;uniform mat4 uIVP;uniform vec3 uEye,uSun,uZen,uHor,uSunC;uniform float uNight,uFade,uHdr,uTime;out vec4 o;\n' + GLN + ACES +
  'void main(){vec4 q=uIVP*vec4(vP,1.,1.);vec3 d=normalize(q.xyz/q.w-uEye);float t=clamp(d.y,0.,1.);vec3 c=mix(uHor,uZen,pow(t,.55));\n' +
  'if(d.y<0.)c=uHor*.85;float s=max(dot(d,uSun),0.);c+=uSunC*(pow(s,900.)*8.+pow(s,10.)*.14);\n' +
  'if(uNight>0.&&d.y>0.){vec3 g=floor(d*420.);float h=fract(sin(dot(g,vec3(12.9898,78.233,37.719)))*43758.5453);c+=vec3(step(.9975,h))*uNight*t*1.5;}\n' +
  'if(d.y>0.){vec2 cp=d.xz/(d.y+.1)*.8+vec2(uTime*.004,uTime*.0015);float n=fb(cp*1.4);float cl=smoothstep(.5,.78,n)*smoothstep(0.,.2,d.y);\n' +
  'vec3 lit=mix(uHor*1.1+vec3(.06),vec3(1.05),.55)*(1.-.88*uNight)+uSunC*.1*pow(s,3.);vec3 sh=mix(lit,uZen*.55+uHor*.35,smoothstep(.62,.95,n)*.55);c=mix(c,sh,cl*.9);}\n' +
  'if(uHdr<.5)c=aces(c);o=vec4(c*uFade,1.);}';
var VSO = '#version 300 es\nlayout(location=0) in vec3 aP;uniform mat4 uVP;uniform vec3 uMin,uMax;void main(){gl_Position=uVP*vec4(mix(uMin,uMax,aP),1.);}';
var FSO = '#version 300 es\nprecision mediump float;uniform vec4 uCol;out vec4 o;void main(){o=uCol;}';
/* pós-processamento */
var VSQ = '#version 300 es\nout vec2 vUv;void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));vUv=p;gl_Position=vec4(p*2.-1.,0.,1.);}';
var FSAO = '#version 300 es\nprecision highp float;in vec2 vUv;uniform sampler2D uDepth;uniform mat4 uP,uIP;uniform vec3 uK[12];uniform float uR,uStr,uScale;out vec4 o;\n' +
  'vec3 vpos(vec2 uv){float d=texture(uDepth,uv).r;vec4 v=uIP*vec4(uv*2.-1.,d*2.-1.,1.);return v.xyz/v.w;}\n' +
  'float h(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}\n' +
  'void main(){float d=texture(uDepth,vUv).r;if(d>=.99999){o=vec4(1.);return;}vec3 P=vpos(vUv);vec3 N=normalize(cross(dFdx(P),dFdy(P)));if(dot(N,P)>0.)N=-N;\n' +
  'float an=h(gl_FragCoord.xy)*6.2831;vec3 rv=vec3(cos(an),sin(an),0.);vec3 T=normalize(rv-N*dot(rv,N));vec3 B=cross(N,T);mat3 M=mat3(T,B,N);\n' +
  'float r=uR*clamp(-P.z*uScale,1.,8.);float oc=0.;\n' +
  'for(int i=0;i<12;i++){vec3 s=P+M*uK[i]*r;vec4 c=uP*vec4(s,1.);vec2 su=c.xy/c.w*.5+.5;if(su.x<0.||su.x>1.||su.y<0.||su.y>1.)continue;float sz=vpos(su).z;float rc=smoothstep(0.,1.,r/max(abs(P.z-sz),1e-4));oc+=(sz>=s.z+.1*r?1.:0.)*rc;}\n' +
  'o=vec4(vec3(pow(clamp(1.-oc/12.,0.,1.),uStr)),1.);}';
var FSAOB = '#version 300 es\nprecision mediump float;in vec2 vUv;uniform sampler2D uT;uniform vec2 uTx;out vec4 o;void main(){float s=0.;for(int x=-2;x<2;x++)for(int y=-2;y<2;y++)s+=texture(uT,vUv+(vec2(x,y)+.5)*uTx).r;o=vec4(vec3(s/16.),1.);}';
var FSBR = '#version 300 es\nprecision highp float;in vec2 vUv;uniform sampler2D uT;uniform float uTh;out vec4 o;void main(){vec3 c=texture(uT,vUv).rgb;float l=dot(c,vec3(.2126,.7152,.0722));o=vec4(c*smoothstep(uTh,uTh*2.2,l),1.);}';
var FSBL = '#version 300 es\nprecision highp float;in vec2 vUv;uniform sampler2D uT;uniform vec2 uDir;out vec4 o;void main(){float w[5]=float[](.227027,.1945946,.1216216,.054054,.016216);vec3 c=texture(uT,vUv).rgb*w[0];for(int i=1;i<5;i++){c+=texture(uT,vUv+uDir*float(i)*1.5).rgb*w[i];c+=texture(uT,vUv-uDir*float(i)*1.5).rgb*w[i];}o=vec4(c,1.);}';
var FSCP = '#version 300 es\nprecision highp float;in vec2 vUv;uniform sampler2D uS,uA,uB;uniform float uFade,uAOs,uBl,uHdr;out vec4 o;\n' + ACES +
  'void main(){vec3 c=texture(uS,vUv).rgb;float ao=texture(uA,vUv).r;c*=mix(1.,ao,uAOs);c+=texture(uB,vUv).rgb*uBl;if(uHdr>.5)c=aces(c);\n' +
  'vec2 v=vUv-.5;c*=1.-.5*dot(v,v);float l=dot(c,vec3(.299,.587,.114));c=mix(vec3(l),c,1.07);o=vec4(c*uFade,1.);}';

var VST = '#version 300 es\nlayout(location=0) in vec3 aP;layout(location=1) in vec2 aU;uniform mat4 uVP,uLVP,uModel;out vec2 vU;out vec3 vW;out vec4 vL;void main(){vec4 w=uModel*vec4(aP,1.);vW=w.xyz;vU=aU;vL=uLVP*w;gl_Position=uVP*w;}';
var FST = '#version 300 es\nprecision highp float;precision highp sampler2DShadow;in vec2 vU;in vec3 vW;in vec4 vL;uniform sampler2D uTx;uniform sampler2DShadow uSh;\n' +
  'uniform vec3 uSun,uFogC,uEye,uTint;uniform vec4 uClip,uUvT,uCol;uniform float uMode,uNight,uFog,uShOn,uSMs,uBias,uHdr,uFade,uK,uClipOn,uHasTex;out vec4 o;\n' + GLN + ACES +
  'float shadow(vec3 N){vec3 p=vL.xyz/vL.w*.5+.5;if(p.x<0.||p.x>1.||p.y<0.||p.y>1.||p.z>1.)return 1.;float b=uBias*(1.5+2.5*(1.-abs(dot(N,uSun))));float s=0.;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=texture(uSh,vec3(p.xy+vec2(x,y)*1.5/uSMs,p.z-b));return s/9.;}\n' +
  'void main(){if(uClipOn>.5&&vW.x>uClip.x&&vW.x<uClip.y&&vW.z>uClip.z&&vW.z<uClip.w&&vW.y>-40.)discard;\n' +
  'vec3 c=uHasTex>.5?texture(uTx,uUvT.xy+vU*uUvT.zw).rgb:uCol.rgb;vec3 col;\n' +
  'if(uMode>.5){col=c*uK;}else{vec3 N=normalize(cross(dFdx(vW),dFdy(vW)));if(dot(N,uEye-vW)<0.)N=-N;float nd=dot(N,uSun);float sh=(uShOn>.5&&nd>0.)?shadow(N):1.;\n' +
  'vec3 day=c*uK*mix(.6,1.,sh)*uTint;vec3 nt=c*.03;float vert=1.-abs(N.y);\n' +
  'if(uNight>.01&&vert>.75&&vW.y>2.5){float h=dot(vW.xz,normalize(vec2(N.z,-N.x)));vec2 f=vec2(fract(h/2.6),fract(vW.y/3.1));float m=step(.22,f.x)*step(f.x,.78)*step(.3,f.y)*step(f.y,.78);float r=hs(vec2(floor(vW.y/3.1),floor(h/2.6))+floor(vW.xz/37.)*7.);nt+=vec3(1.,.74,.45)*m*step(.74,r)*(1.2+r);}\n' +
  'col=mix(day,nt,uNight);}\n' +
  'float d=length(vW-uEye);col=mix(col,uFogC,1.-exp(-d*uFog));if(uHdr<.5)col=aces(col);o=vec4(col*uFade,1.);}';
var VSDM = '#version 300 es\nlayout(location=0) in vec3 aP;uniform mat4 uLVP,uModel;out vec3 vW;void main(){vec4 w=uModel*vec4(aP,1.);vW=w.xyz;gl_Position=uLVP*w;}';
var FSDM = '#version 300 es\nprecision mediump float;in vec3 vW;uniform vec4 uClip;uniform float uClipOn;void main(){if(uClipOn>.5&&vW.x>uClip.x&&vW.x<uClip.y&&vW.z>uClip.z&&vW.z<uClip.w&&vW.y>-40.)discard;}';
var VSPT = '#version 300 es\nlayout(location=0) in vec3 aP;layout(location=1) in vec3 aC;uniform mat4 uVP;uniform float uS;out vec3 vC;void main(){gl_Position=uVP*vec4(aP,1.);gl_PointSize=clamp(uS/gl_Position.w,2.,9.);vC=aC;}';
var FSPT = '#version 300 es\nprecision mediump float;in vec3 vC;uniform float uI;out vec4 o;void main(){float d=length(gl_PointCoord-.5);float a=smoothstep(.5,.05,d);o=vec4(vC*uI*a,a);}';
function prog(gl, vs, fs) {
  function sh(t, s) { var x = gl.createShader(t); gl.shaderSource(x, s); gl.compileShader(x); if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(x)); return x; }
  var p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  var u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (var i = 0; i < n; i++) { var info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
  return { p: p, u: u };
}

/* ======================================================================
   ENGINE
   ====================================================================== */
/* ======================================================================
   GEO / 3D TILES / glTF
   ====================================================================== */
var WGS_A = 6378137, WGS_E2 = 6.69437999014e-3;
function geo2ecef(lat, lon, h) {
  var p = lat * PI / 180, l = lon * PI / 180, s = Math.sin(p), N = WGS_A / Math.sqrt(1 - WGS_E2 * s * s);
  return [(N + h) * Math.cos(p) * Math.cos(l), (N + h) * Math.cos(p) * Math.sin(l), (N * (1 - WGS_E2) + h) * s];
}
function ecef2geo(x, y, z) {
  var lon = Math.atan2(y, x), p = Math.hypot(x, y), lat = Math.atan2(z, p * (1 - WGS_E2)), h = 0;
  for (var i = 0; i < 6; i++) { var s = Math.sin(lat), N = WGS_A / Math.sqrt(1 - WGS_E2 * s * s); h = p / Math.cos(lat) - N; lat = Math.atan2(z, p * (1 - WGS_E2 * N / (N + h))); }
  return { lat: lat * 180 / PI, lon: lon * 180 / PI, h: h };
}
/* 4x4 em Float64 (coluna-maior) */
var D4 = {
  I: function () { return new Float64Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); },
  mul: function (a, b) { var o = new Float64Array(16); for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) { var s = 0; for (var k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
  inv: function (m) { return new Float64Array(M4.inv(m)); },
  pt: function (m, x, y, z) { return [m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]]; },
  dir: function (m, x, y, z) { return [m[0] * x + m[4] * y + m[8] * z, m[1] * x + m[5] * y + m[9] * z, m[2] * x + m[6] * y + m[10] * z]; },
  trs: function (n) {
    if (n.matrix) return new Float64Array(n.matrix);
    var t = n.translation || [0, 0, 0], q = n.rotation || [0, 0, 0, 1], s = n.scale || [1, 1, 1], x = q[0], y = q[1], z = q[2], w = q[3];
    return new Float64Array([(1 - 2 * (y * y + z * z)) * s[0], (2 * (x * y + z * w)) * s[0], (2 * (x * z - y * w)) * s[0], 0, (2 * (x * y - z * w)) * s[1], (1 - 2 * (x * x + z * z)) * s[1], (2 * (y * z + x * w)) * s[1], 0, (2 * (x * z + y * w)) * s[2], (2 * (y * z - x * w)) * s[2], (1 - 2 * (x * x + y * y)) * s[2], 0, t[0], t[1], t[2], 1]);
  }
};
var YUP2ZUP = new Float64Array([1, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 1]);

/* referencial do terreno: x = oeste (espelhado), y = cima, z = norte, girado pelo azimute A da fachada */
function SiteFrame(lat, lon, h, headingDeg) { this.set(lat, lon, h, headingDeg); }
SiteFrame.prototype.set = function (lat, lon, h, headingDeg) {
  this.lat = lat; this.lon = lon; this.h = h; this.heading = headingDeg;
  var p = lat * PI / 180, l = lon * PI / 180, A = headingDeg * PI / 180, cA = Math.cos(A), sA = Math.sin(A);
  var E = [-Math.sin(l), Math.cos(l), 0], N = [-Math.sin(p) * Math.cos(l), -Math.sin(p) * Math.sin(l), Math.cos(p)], U = [Math.cos(p) * Math.cos(l), Math.cos(p) * Math.sin(l), Math.sin(p)];
  var r0 = [cA * -E[0] + sA * N[0], cA * -E[1] + sA * N[1], cA * -E[2] + sA * N[2]];
  var r2 = [sA * E[0] + cA * N[0], sA * E[1] + cA * N[1], sA * E[2] + cA * N[2]];
  this.R = [r0, U, r2]; this.E = E; this.N = N; this.U = U; this.cA = cA; this.sA = sA;
  this.O = geo2ecef(lat, lon, h);
  var R = this.R, O = this.O;
  this.S = new Float64Array([R[0][0], R[1][0], R[2][0], 0, R[0][1], R[1][1], R[2][1], 0, R[0][2], R[1][2], R[2][2], 0,
    -(R[0][0] * O[0] + R[0][1] * O[1] + R[0][2] * O[2]), -(R[1][0] * O[0] + R[1][1] * O[1] + R[1][2] * O[2]), -(R[2][0] * O[0] + R[2][1] * O[1] + R[2][2] * O[2]), 1]);
  this.ver = (this.ver || 0) + 1;
};
SiteFrame.prototype.fromEcef = function (p) { return D4.pt(this.S, p[0], p[1], p[2]); };
SiteFrame.prototype.fromGeo = function (lat, lon, h) { return this.fromEcef(geo2ecef(lat, lon, h)); };
SiteFrame.prototype.toGeo = function (s) {
  var wx = this.cA * s[0] - this.sA * s[2], wz = this.sA * s[0] + this.cA * s[2], east = -wx, north = wz, up = s[1], O = this.O, E = this.E, N = this.N, U = this.U;
  return ecef2geo(O[0] + E[0] * east + N[0] * north + U[0] * up, O[1] + E[1] * east + N[1] * north + U[1] * up, O[2] + E[2] * east + N[2] * north + U[2] * up);
};
/* direção do sol (no referencial x=oeste, z=norte) para o referencial do terreno */
SiteFrame.prototype.dirToSite = function (d) { return [this.cA * d[0] + this.sA * d[2], d[1], -this.sA * d[0] + this.cA * d[2]]; };

/* ---------------- Draco (decodificador oficial do Google, carregado sob demanda) ---------------- */
var DRACO = null;
function dracoModule() {
  if (DRACO) return DRACO;
  var base = 'https://www.gstatic.com/draco/versioned/decoders/1.5.7/';
  DRACO = new Promise(function (resolve, reject) {
    var s = document.createElement('script'); s.src = base + 'draco_wasm_wrapper.js'; s.async = true;
    s.onerror = function () { reject(new Error('Falha ao carregar o decodificador Draco')); };
    s.onload = function () {
      fetch(base + 'draco_decoder.wasm').then(function (r) { return r.arrayBuffer(); }).then(function (wasm) {
        /* global DracoDecoderModule */
        DracoDecoderModule({ wasmBinary: wasm, onModuleLoaded: function (m) { resolve(m); } });
      }).catch(reject);
    };
    document.head.appendChild(s);
  });
  return DRACO;
}
function dracoDecode(D, bytes, attrMap) {
  var dec = new D.Decoder(), mesh = new D.Mesh(), arr = new Int8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  var st = dec.DecodeArrayToMesh(arr, arr.byteLength, mesh);
  if (!st.ok() || mesh.ptr === 0) { D.destroy(mesh); D.destroy(dec); throw new Error('Draco: ' + st.error_msg()); }
  var out = { attrs: {} }, nf = mesh.num_faces(), ni = nf * 3, bl = ni * 4, ptr = D._malloc(bl);
  dec.GetTrianglesUInt32Array(mesh, bl, ptr); out.index = new Uint32Array(D.HEAPF32.buffer, ptr, ni).slice(); D._free(ptr);
  var np = mesh.num_points();
  Object.keys(attrMap).forEach(function (name) {
    var a = dec.GetAttributeByUniqueId(mesh, attrMap[name]); if (!a || !a.ptr) return;
    var nc = a.num_components(), nv = np * nc, b2 = nv * 4, p2 = D._malloc(b2);
    dec.GetAttributeDataArrayForAllPoints(mesh, a, D.DT_FLOAT32, b2, p2);
    out.attrs[name] = { data: new Float32Array(D.HEAPF32.buffer, p2, nv).slice(), n: nc }; D._free(p2);
  });
  D.destroy(mesh); D.destroy(dec); return out;
}

/* ---------------- leitor de glTF/GLB (malhas texturizadas) ---------------- */
var CTYPE = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array };
var NCOMP = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
var NORMDIV = { 5120: 127, 5121: 255, 5122: 32767, 5123: 65535 };
function parseGlb(ab) {
  var dv = new DataView(ab);
  if (dv.getUint32(0, true) !== 0x46546C67) return { json: JSON.parse(new TextDecoder().decode(new Uint8Array(ab))), bin: null };
  var len = dv.getUint32(8, true), off = 12, json = null, bin = null;
  while (off < len) { var cl = dv.getUint32(off, true), ct = dv.getUint32(off + 4, true); if (ct === 0x4E4F534A) json = JSON.parse(new TextDecoder().decode(new Uint8Array(ab, off + 8, cl))); else if (ct === 0x004E4942) bin = ab.slice(off + 8, off + 8 + cl); off += 8 + cl; }
  return { json: json, bin: bin };
}
function gltfAccessor(j, bufs, i) {
  var a = j.accessors[i], bv = j.bufferViews[a.bufferView], T = CTYPE[a.componentType], n = NCOMP[a.type], off = (bv.byteOffset || 0) + (a.byteOffset || 0), bpe = T.BYTES_PER_ELEMENT, st = bv.byteStride || n * bpe;
  var buf = bufs[bv.buffer], out;
  if (st === n * bpe && off % bpe === 0) out = new T(buf, off, a.count * n);
  else { out = new T(a.count * n); var src = new DataView(buf); var get = { 5126: 'getFloat32', 5125: 'getUint32', 5123: 'getUint16', 5122: 'getInt16', 5121: 'getUint8', 5120: 'getInt8' }[a.componentType]; for (var k = 0; k < a.count; k++) for (var c = 0; c < n; c++) out[k * n + c] = src[get](off + k * st + c * bpe, true); }
  if (a.normalized && T !== Float32Array && n !== 1) { var f = new Float32Array(out.length), d = NORMDIV[a.componentType]; for (var q = 0; q < out.length; q++) f[q] = Math.max(out[q] / d, -1); return f; }
  return out;
}
/* devolve { prims:[{pos, uv, index, matrix(Float64), img(Promise<ImageBitmap>|null), uvT, name}], copyright } */
function loadGltf(ab, opt) {
  opt = opt || {};
  var g = parseGlb(ab), j = g.json, bufs = (j.buffers || []).map(function (b) { return b.uri ? null : g.bin; });
  var need = (j.extensionsUsed || []).indexOf('KHR_draco_mesh_compression') >= 0;
  var pre = need ? dracoModule() : Promise.resolve(null);
  return pre.then(function (D) {
    var imgCache = {};
    function image(texIndex) {
      if (texIndex == null || !j.textures || !j.textures[texIndex]) return null;
      var src = j.textures[texIndex].source; if (src == null && j.textures[texIndex].extensions) { var ex = j.textures[texIndex].extensions; src = (ex.EXT_texture_webp || ex.KHR_texture_basisu || {}).source; }
      if (src == null) return null; if (imgCache[src]) return imgCache[src];
      var im = j.images[src], blob;
      if (im.bufferView != null) { var bv = j.bufferViews[im.bufferView]; blob = new Blob([new Uint8Array(bufs[bv.buffer], bv.byteOffset || 0, bv.byteLength)], { type: im.mimeType || 'image/jpeg' }); imgCache[src] = createImageBitmap(blob, { imageOrientation: 'none', premultiplyAlpha: 'none', colorSpaceConversion: 'none' }); }
      else if (im.uri) imgCache[src] = fetch(new URL(im.uri, opt.base || location.href)).then(function (r) { return r.blob(); }).then(function (b) { return createImageBitmap(b, { imageOrientation: 'none' }); });
      return imgCache[src];
    }
    var prims = [];
    function node(i, pm) {
      var n = j.nodes[i], m = D4.mul(pm, D4.trs(n));
      if (n.mesh != null) j.meshes[n.mesh].primitives.forEach(function (p) {
        if (p.mode != null && p.mode !== 4) return;
        var mat = p.material != null && j.materials ? j.materials[p.material] : {}, pb = mat.pbrMetallicRoughness || {}, bt = pb.baseColorTexture, tc = bt && bt.texCoord ? bt.texCoord : 0;
        var pos, uv, idx, dr = p.extensions && p.extensions.KHR_draco_mesh_compression;
        if (dr && D) {
          var bv = j.bufferViews[dr.bufferView], bytes = new Uint8Array(bufs[bv.buffer], bv.byteOffset || 0, bv.byteLength), map = {};
          map.POSITION = dr.attributes.POSITION; if (dr.attributes['TEXCOORD_' + tc] != null) map.UV = dr.attributes['TEXCOORD_' + tc];
          var r = dracoDecode(D, bytes, map); pos = r.attrs.POSITION.data; idx = r.index;
          if (r.attrs.UV) { uv = r.attrs.UV.data; var ua = j.accessors[p.attributes['TEXCOORD_' + tc]]; if (ua && ua.normalized && NORMDIV[ua.componentType]) { var dd = NORMDIV[ua.componentType]; for (var q = 0; q < uv.length; q++) uv[q] /= dd; } }
        } else {
          pos = gltfAccessor(j, bufs, p.attributes.POSITION);
          if (!(pos instanceof Float32Array)) pos = Float32Array.from(pos);
          if (p.attributes['TEXCOORD_' + tc] != null) { uv = gltfAccessor(j, bufs, p.attributes['TEXCOORD_' + tc]); if (!(uv instanceof Float32Array)) uv = Float32Array.from(uv); }
          if (p.indices != null) idx = gltfAccessor(j, bufs, p.indices);
        }
        var tt = bt && bt.extensions && bt.extensions.KHR_texture_transform;
        prims.push({ pos: pos, uv: uv || null, index: idx || null, matrix: m, img: bt ? image(bt.index) : null, color: pb.baseColorFactor || [1, 1, 1, 1], uvT: tt ? [tt.offset ? tt.offset[0] : 0, tt.offset ? tt.offset[1] : 0, tt.scale ? tt.scale[0] : 1, tt.scale ? tt.scale[1] : 1] : [0, 0, 1, 1], name: n.name || '' });
      });
      (n.children || []).forEach(function (c) { node(c, m); });
    }
    var sc = j.scenes ? j.scenes[j.scene || 0] : { nodes: j.nodes.map(function (_, i) { return i; }) };
    sc.nodes.forEach(function (i) { node(i, D4.I()); });
    return { prims: prims, copyright: (j.asset && j.asset.copyright) || '' };
  });
}
/* sobe as malhas para a GPU */
function uploadPrims(gl, prims) {
  return Promise.all(prims.map(function (p) { return p.img ? p.img.catch(function () { return null; }) : null; })).then(function (imgs) {
    return prims.map(function (p, i) {
      var vao = gl.createVertexArray(), bufs = []; gl.bindVertexArray(vao);
      var b = gl.createBuffer(); bufs.push(b); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, p.pos, gl.STATIC_DRAW); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
      if (p.uv) { var b2 = gl.createBuffer(); bufs.push(b2); gl.bindBuffer(gl.ARRAY_BUFFER, b2); gl.bufferData(gl.ARRAY_BUFFER, p.uv, gl.STATIC_DRAW); gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 0, 0); } else { gl.disableVertexAttribArray(1); gl.vertexAttrib2f(1, 0, 0); }
      var it = null, cnt = p.pos.length / 3;
      if (p.index) { var bi = gl.createBuffer(); bufs.push(bi); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bi); var I = p.index; if (I instanceof Uint8Array) I = Uint16Array.from(I); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, I, gl.STATIC_DRAW); it = I instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT; cnt = I.length; p.index = I; }
      gl.bindVertexArray(null);
      var tex = null, img = imgs[i];
      if (img) { tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.texImage2D(gl.TEXTURE_2D, 0, gl.SRGB8_ALPHA8, gl.RGBA, gl.UNSIGNED_BYTE, img); gl.generateMipmap(gl.TEXTURE_2D); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); if (img.close) img.close(); }
      return { vao: vao, bufs: bufs, tex: tex, it: it, cnt: cnt, matrix: p.matrix, color: p.color, uvT: p.uvT, name: p.name, pos: p.pos, index: p.index, bytes: p.pos.byteLength * 1.7 };
    });
  });
}
function freePrims(gl, ps) { (ps || []).forEach(function (p) { gl.deleteVertexArray(p.vao); p.bufs.forEach(function (b) { gl.deleteBuffer(b); }); if (p.tex) gl.deleteTexture(p.tex); }); }

/* raio x triângulos (Möller–Trumbore) em espaço do modelo */
function rayPrim(p, o, d) {
  var P = p.pos, I = p.index, n = I ? I.length : P.length / 3, best = Infinity;
  for (var t = 0; t < n; t += 3) {
    var a = (I ? I[t] : t) * 3, b = (I ? I[t + 1] : t + 1) * 3, c = (I ? I[t + 2] : t + 2) * 3;
    var e1x = P[b] - P[a], e1y = P[b + 1] - P[a + 1], e1z = P[b + 2] - P[a + 2], e2x = P[c] - P[a], e2y = P[c + 1] - P[a + 1], e2z = P[c + 2] - P[a + 2];
    var px = d[1] * e2z - d[2] * e2y, py = d[2] * e2x - d[0] * e2z, pz = d[0] * e2y - d[1] * e2x, det = e1x * px + e1y * py + e1z * pz;
    if (Math.abs(det) < 1e-12) continue; var inv = 1 / det;
    var tx = o[0] - P[a], ty = o[1] - P[a + 1], tz = o[2] - P[a + 2], u = (tx * px + ty * py + tz * pz) * inv; if (u < 0 || u > 1) continue;
    var qx = ty * e1z - tz * e1y, qy = tz * e1x - tx * e1z, qz = tx * e1y - ty * e1x, v = (d[0] * qx + d[1] * qy + d[2] * qz) * inv; if (v < 0 || u + v > 1) continue;
    var tt = (e2x * qx + e2y * qy + e2z * qz) * inv; if (tt > 1e-6 && tt < best) best = tt;
  }
  return best;
}

/* ---------------- gerenciador de 3D Tiles ---------------- */
function Tiles(engine, cfg) {
  this.e = engine; this.gl = engine.gl; this.cfg = cfg; this.frame = 0; this.queue = []; this.active = 0; this.gpu = 0; this.drawn = [];
  this.maxReq = cfg.maxRequests || 10; this.maxSSE = cfg.sse || 16; this.budget = (cfg.memoryMB || 700) * 1e6;
  this.status = 'carregando'; this.copyright = ''; this.ready = false; this.loaded = 0; this.failed = 0;
  var self = this;
  this._fetchJson(cfg.url, null).then(function (j) {
    self.rootUrl = self.lastUrl; self.root = self._mk(j.root, null, self.rootUrl); self.status = 'ok'; self.ready = true; engine.shadowDirty = true;
  }).catch(function (err) { self.status = 'erro'; self.error = String(err && err.message || err); engine._tilesFailed(self.error); });
}
Tiles.prototype = {
  _u: function (uri, base) {
    var x = new URL(uri, base || location.href);
    if (!this.session) { var s = x.searchParams.get('session'); if (s) this.session = s; }
    if (this.cfg.key) x.searchParams.set('key', this.cfg.key);
    if (this.session && !x.searchParams.has('session') && this.cfg.key) x.searchParams.set('session', this.session);
    return x.toString();
  },
  _fetchJson: function (uri, base) {
    var u = this._u(uri, base), self = this; this.lastUrl = u;
    return fetch(u).then(function (r) { if (!r.ok) return r.text().then(function (t) { throw new Error('HTTP ' + r.status + ' ' + t.slice(0, 160)); }); return r.json(); }).then(function (j) {
      /* procura a sessão nos filhos */
      (function find(t, d) { if (self.session || !t || d > 3) return; var c = t.content && (t.content.uri || t.content.url); if (c) { try { var s = new URL(c, u).searchParams.get('session'); if (s) self.session = s; } catch (e) { } } (t.children || []).forEach(function (k) { find(k, d + 1); }); })(j.root, 0);
      return j;
    });
  },
  _mk: function (j, parent, base) {
    var T = j.transform ? new Float64Array(j.transform) : null, PT = parent ? parent.T : D4.I(), t = { j: j, parent: parent, base: base, T: T ? D4.mul(PT, T) : PT, geo: j.geometricError, refine: (j.refine || (parent && parent.refine) || 'REPLACE').toUpperCase(), children: [], state: 0, last: 0 };
    var c = j.content && (j.content.uri || j.content.url); t.uri = c || null;
    if (c) { var path = c.split('?')[0].toLowerCase(); t.kind = /\.json$/.test(path) ? 'json' : 'glb'; } else t.kind = 'none';
    var bv = j.boundingVolume || {};
    if (bv.box) { var b = bv.box, cc = D4.pt(t.T, b[0], b[1], b[2]), a1 = D4.dir(t.T, b[3], b[4], b[5]), a2 = D4.dir(t.T, b[6], b[7], b[8]), a3 = D4.dir(t.T, b[9], b[10], b[11]); t.bc = cc; t.br = Math.sqrt(a1[0] * a1[0] + a1[1] * a1[1] + a1[2] * a1[2] + a2[0] * a2[0] + a2[1] * a2[1] + a2[2] * a2[2] + a3[0] * a3[0] + a3[1] * a3[1] + a3[2] * a3[2]); }
    else if (bv.sphere) { var s = bv.sphere; t.bc = D4.pt(t.T, s[0], s[1], s[2]); t.br = s[3]; }
    else if (bv.region) { var r = bv.region, la = (r[1] + r[3]) / 2 * 180 / PI, lo = (r[0] + r[2]) / 2 * 180 / PI; t.bc = geo2ecef(la, lo, (r[4] + r[5]) / 2); var c2 = geo2ecef(r[3] * 180 / PI, r[2] * 180 / PI, r[5]); t.br = Math.hypot(c2[0] - t.bc[0], c2[1] - t.bc[1], c2[2] - t.bc[2]) * 1.2; }
    else { t.bc = [0, 0, 0]; t.br = 1e9; }
    var self = this; t.children = (j.children || []).map(function (k) { return self._mk(k, t, base); });
    return t;
  },
  _site: function (t) { var F = this.e.frame; if (t.sv !== F.ver) { t.sv = F.ver; t.sc = F.fromEcef(t.bc); } return t.sc; },
  _request: function (t, pri) { if (t.state !== 0 || !t.uri) return; t.state = 1; t.pri = pri; this.queue.push(t); },
  _pump: function () {
    if (!this.queue.length || this.active >= this.maxReq) return;
    var f = this.frame; this.queue = this.queue.filter(function (t) { if (f - t.last > 2 && t.state === 1) { t.state = 0; return false; } return true; });
    this.queue.sort(function (a, b) { return a.pri - b.pri; });
    var self = this;
    while (this.active < this.maxReq && this.queue.length) {
      var t = this.queue.shift(); t.state = 2; this.active++;
      (function (t) {
        var u = self._u(t.uri, t.base), done = function () { self.active--; };
        if (t.kind === 'json') {
          self._fetchJson(t.uri, t.base).then(function (j) { var sub = self._mk(j.root, t, self.lastUrl); t.children = [sub]; t.state = 3; done(); }).catch(function (e) { t.state = 4; self.failed++; done(); });
        } else {
          fetch(u).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); }).then(function (ab) { return loadGltf(ab); }).then(function (g) {
            t.copyright = g.copyright; return uploadPrims(self.gl, g.prims);
          }).then(function (ps) {
            if (t.state !== 2) { freePrims(self.gl, ps); done(); return; }
            ps.forEach(function (p) { p.ecef = D4.mul(t.T, D4.mul(YUP2ZUP, p.matrix)); });
            t.prims = ps; t.bytes = ps.reduce(function (s, p) { return s + p.bytes; }, 0); self.gpu += t.bytes; t.state = 3; self.loaded++; self.e.shadowDirty = true; done();
          }).catch(function (e) { t.state = 4; self.failed++; self.lastErr = String(e && e.message || e); done(); });
        }
      })(t);
    }
  },
  _ready: function (t) { return t.state === 3 || t.kind === 'none'; },
  update: function (E, planes, H, fov) {
    if (!this.root) return;
    this.frame++; var f = this.frame, self = this, k = H / (2 * Math.tan(fov / 2)), list = [], maxSSE = this.maxSSE;
    function vis(t) { var c = self._site(t); for (var i = 0; i < 6; i++) { var p = planes[i]; if (p[0] * c[0] + p[1] * c[1] + p[2] * c[2] + p[3] < -t.br) return false; } return true; }
    function dist(t) { var c = self._site(t); return Math.max(0.5, Math.hypot(c[0] - E[0], c[1] - E[1], c[2] - E[2]) - t.br); }
    function visit(t, depth) {
      if (!vis(t)) return;
      t.last = f; var d = dist(t), sse = t.geo * k / d;
      if (t.kind !== 'none' && t.state === 0) self._request(t, t.kind === 'json' ? -1 : d / (depth + 1));
      if (t.kind === 'json') { if (t.state === 3) t.children.forEach(function (c) { visit(c, depth + 1); }); return; }
      var refine = t.children.length > 0 && sse > maxSSE;
      if (!refine) { if (t.state === 3) list.push(t); return; }
      var kids = t.children.filter(vis), ready = kids.every(function (c) { return c.kind === 'json' ? c.state === 3 : self._ready(c); });
      if (ready || t.state !== 3) kids.forEach(function (c) { visit(c, depth + 1); });
      else { list.push(t); kids.forEach(function (c) { c.last = f; if (c.state === 0) self._request(c, dist(c) / (depth + 2)); }); }
    }
    visit(this.root, 0);
    this.drawn = list; this._pump();
    /* memória */
    if (this.gpu > this.budget && f % 30 === 0) {
      var all = []; (function walk(t) { if (t.prims) all.push(t); t.children.forEach(walk); })(this.root);
      all.sort(function (a, b) { return a.last - b.last; });
      for (var i = 0; i < all.length && this.gpu > this.budget * 0.8; i++) { var t = all[i]; if (f - t.last < 5) break; freePrims(this.gl, t.prims); this.gpu -= t.bytes; t.prims = null; t.state = 0; }
    }
    if (f % 15 === 0) {
      var cnt = {}; list.forEach(function (t) { (t.copyright || '').split(';').forEach(function (s) { s = s.trim(); if (s) cnt[s] = (cnt[s] || 0) + 1; }); });
      var txt = Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a]; }).join('; ');
      if (txt !== this.copyright) { this.copyright = txt; this.e.opts.onAttribution && this.e.opts.onAttribution(txt); }
    }
  },
  each: function (fn) { var F = this.e.frame; this.drawn.forEach(function (t) { t.prims.forEach(function (p) { if (p.sv !== F.ver) { p.sv = F.ver; p.site = D4.mul(F.S, p.ecef); p.site32 = new Float32Array(p.site); } fn(p, t); }); }); },
  raycast: function (o, d) {
    var best = null, bt = Infinity;
    this.each(function (p) {
      var inv = D4.inv(p.site), lo = D4.pt(inv, o[0], o[1], o[2]), ld = D4.dir(inv, d[0], d[1], d[2]), t = rayPrim(p, lo, ld);
      if (t < Infinity) { var hp = D4.pt(p.site, lo[0] + ld[0] * t, lo[1] + ld[1] * t, lo[2] + ld[2] * t), dd = Math.hypot(hp[0] - o[0], hp[1] - o[1], hp[2] - o[2]); if (dd < bt) { bt = dd; best = hp; } }
    });
    return best;
  },
  idle: function () { return this.active === 0 && this.queue.length === 0; }
};

/* ---------------- luzes da ponte (pontos brilhantes) ---------------- */
function bridgePoints(F, cfg) {
  var t1, t2;
  if (cfg.t1 && cfg.t2) { t1 = F.fromGeo(cfg.t1.lat, cfg.t1.lon, cfg.t1.h); t2 = F.fromGeo(cfg.t2.lat, cfg.t2.lon, cfg.t2.h); }
  else {
    var c = F.fromGeo(cfg.lat, cfg.lon, F.h), az = (cfg.heading || 62) * PI / 180, half = (cfg.span || 339.5) / 2;
    var ax = [-Math.sin(az), 0, Math.cos(az)], s = F.dirToSite(ax), top = (cfg.seaY != null ? cfg.seaY : -2) + (cfg.towerH || 74);
    t1 = [c[0] - s[0] * half, top, c[2] - s[2] * half]; t2 = [c[0] + s[0] * half, top, c[2] + s[2] * half];
  }
  var sea = cfg.seaY != null ? cfg.seaY : Math.max(t1[1], t2[1]) - (cfg.towerH || 74);
  var ux = t2[0] - t1[0], uz = t2[2] - t1[2], L = Math.hypot(ux, uz); ux /= L; uz /= L; var wx = -uz, wz = ux;
  var deck = sea + (cfg.deckH || 31), mid = sea + (cfg.chainMidH || 41), side = cfg.sideSpan || L * 0.31, half2 = (cfg.width || 11) / 2;
  var pts = [], warm = [1.0, 0.86, 0.62], white = [0.95, 0.95, 1.0];
  function add(x, y, z, c) { pts.push(x, y, z, c[0], c[1], c[2]); }
  [-half2, half2].forEach(function (o) {
    var ox = wx * o, oz = wz * o;
    /* vão central: catenária */
    for (var i = 0; i <= 160; i++) { var s = i / 160, y = t1[1] + (t2[1] - t1[1]) * s, sag = 4 * s * (1 - s); add(t1[0] + ux * L * s + ox, y - (y - mid) * sag, t1[2] + uz * L * s + oz, warm); }
    /* vãos laterais */
    [[t1, -1], [t2, 1]].forEach(function (q) { var T = q[0], sg = q[1]; for (var i = 1; i <= 50; i++) { var s = i / 50, x = T[0] + ux * side * s * sg, z = T[2] + uz * side * s * sg, y = T[1] + (deck - T[1]) * Math.pow(s, 0.85); add(x + ox, y, z + oz, warm); } });
    /* tabuleiro */
    for (var k = -side; k <= L + side; k += 3) add(t1[0] + ux * k + ox * 0.9, deck - 2.5, t1[2] + uz * k + oz * 0.9, white);
  });
  /* torres */
  [t1, t2].forEach(function (T) { [-1, 1].forEach(function (a) { [-1, 1].forEach(function (b) { for (var y = sea + 2; y <= T[1]; y += 1.6) add(T[0] + wx * half2 * b + ux * 3 * a, y, T[2] + wz * half2 * b + uz * 3 * a, white); }); }); });
  return { data: new Float32Array(pts), t1: t1, t2: t2, sea: sea };
}

function viewFrom(E, T) { var dx = E[0] - T[0], dy = E[1] - T[1], dz = E[2] - T[2], d = Math.hypot(dx, dy, dz); return { t: T.slice(), d: d, yaw: Math.atan2(dx, dz), pitch: Math.asin(dy / d) }; }
function add3(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }

function Engine(canvas, opts) {
  opts = opts || {};
  var self = this; this.canvas = canvas; this.opts = opts;
  var gl = canvas.getContext('webgl2', { antialias: true, alpha: false, preserveDrawingBuffer: !!opts.preserve });
  if (!gl) throw new Error('Seu navegador não suporta WebGL2.');
  this.gl = gl;
  this.P = prog(gl, VS, FS); this.PD = prog(gl, VSD, FSD); this.PS = prog(gl, VSS, FSS); this.PO = prog(gl, VSO, FSO);
  this.vaoSky = gl.createVertexArray();
  this.PT = prog(gl, VST, FST); this.PDM = prog(gl, VSDM, FSDM); this.PPT = prog(gl, VSPT, FSPT);
  this.hdr = !!gl.getExtension('EXT_color_buffer_float');
  this.PP = { ao: prog(gl, VSQ, FSAO), aob: prog(gl, VSQ, FSAOB), br: prog(gl, VSQ, FSBR), bl: prog(gl, VSQ, FSBL), cp: prog(gl, VSQ, FSCP) };
  var kr = rng(5), K = new Float32Array(36);
  for (var ki = 0; ki < 12; ki++) { var v = [kr() * 2 - 1, kr() * 2 - 1, kr() * 0.85 + 0.15], vl = Math.hypot(v[0], v[1], v[2]), sc0 = 0.15 + 0.85 * Math.pow((ki + 1) / 12, 2); K[ki * 3] = v[0] / vl * sc0; K[ki * 3 + 1] = v[1] / vl * sc0; K[ki * 3 + 2] = v[2] / vl * sc0; }
  this.kernel = K; this.postOK = opts.post !== false; this.T = null;
  this._lp = new Float32Array(36); this._lc = new Float32Array(36);
  /* mapa de sombra */
  this.SM = gl.getParameter(gl.MAX_TEXTURE_SIZE) >= 4096 ? 4096 : 2048; this.shTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, this.shTex);
  gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT24, this.SM, this.SM);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
  this.shFbo = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, this.shFbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.shTex, 0);
  gl.drawBuffers([gl.NONE]); gl.readBuffer(gl.NONE); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  /* caixa unitária para destaque */
  var cube = [], e = [], V = [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]];
  [[0, 1, 2, 3], [5, 4, 7, 6], [4, 0, 3, 7], [1, 5, 6, 2], [3, 2, 6, 7], [4, 5, 1, 0]].forEach(function (f) { [f[0], f[1], f[2], f[0], f[2], f[3]].forEach(function (i) { cube.push.apply(cube, V[i]); }); });
  [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(function (l) { e.push.apply(e, V[l[0]]); e.push.apply(e, V[l[1]]); });
  this.cubeVao = this._vaoPos(new Float32Array(cube)); this.edgeVao = this._vaoPos(new Float32Array(e));

  /* geometria */
  var available = opts.available || [];
  this.buffers = {}; this.picks = [];
  var gCity = new Geo(); buildTerrain(gCity); buildCity(gCity);
  var G = opts.google || null;
  if (G) { this.frame = new SiteFrame(G.lat, G.lon, G.h || 3, G.heading || 0); this.clip = G.clip || [-41, 41, -21, 24.5]; }
  var gSite = new Geo(), gRoof = new Geo(); buildSite(gSite, gRoof, !!G);
  var gA = new Geo(), gB = new Geo(); buildTower(gA, 'A', available, this.picks, 1.0); buildTower(gB, 'B', available, this.picks, 1.0);
  var g1 = new Geo(), g2 = new Geo(); buildApt1(g1); buildApt2(g2);
  this._upload('city', gCity); this._upload('site', gSite); this._upload('roofs', gRoof); this._upload('towerA', gA); this._upload('towerB', gB); this._upload('apt1', g1); this._upload('apt2', g2);

  var top = TOWER.G + TOWER.NF * TOWER.FH;
  this.scenes = {
    site: {
      layers: [{ key: 'city' }, { key: 'site' }, { key: 'roofs' }, { key: 'towerA' }, { key: 'towerB' }],
      fov: 42, fog: 0.0009, shadowC: [0, 20, 0], shadowR: 70, indoor: false, ao: { r: 0.7, s: 1.5, sc: 0.025, k: 0.8 },
      lights: [{ p: [-42, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [-28, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [-14, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [0, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [14, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [28, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [42, 5.3, 23.2], c: [1.0, 0.7, 0.42], m: 10 }, { p: [6.6, 2.1, -8.6], c: [1.0, 0.7, 0.42], m: 4 }, { p: [-8.6, 2.2, -10.2], c: [1.0, 0.7, 0.42], m: 3 }, { p: [0, 0.9, 5.5], c: [0.3, 0.8, 1.0], m: 5 }, { p: [-9.5, 2.6, 14.2], c: [1.0, 0.7, 0.42], m: 2.5 }, { p: [9.4, 2.8, 14.0], c: [1.0, 0.7, 0.42], m: 2 }],
      lim: { minD: 3, maxD: 460, minP: 0.03, maxP: 1.48, box: [-260, 260, -260, 260], minEye: 0.7 },
      anchors: { torreA: [-24, top + 9, 0], torreB: [24, top + 9, 0], lazer: [0, 6, 6], piscina: [0, 1.6, 5.5], sombra: [-9.5, 3.9, 14.2], kids: [9.4, 4.0, 14.2], jogos: [-7.4, 4.2, -9.4], gourmet: [7.4, 4.2, -9.4], palmeiras: [-9.6, 9.5, 5.4] },
      views: {
        overview: { t: [0, 22, 0], d: 150, yaw: 0.62, pitch: 0.28 },
        aerial: { t: [0, 0, 0], d: 200, yaw: 0.28, pitch: 1.12 },
        front: { t: [0, 27, 0], d: 112, yaw: 0.0, pitch: 0.1 },
        lazer: { t: [0, 0, 1.5], d: 48, yaw: 0.45, pitch: 0.66 },
        piscina: viewFrom([5.5, 2.6, 13.5], [-1, 0.4, 4.5]),
        sombra: viewFrom([-4.8, 2.3, 17.6], [-10.2, 0.8, 13.6]),
        kids: viewFrom([4.4, 2.6, 18.2], [9.6, 0.8, 13.6]),
        jogos: viewFrom([-3.6, 2.4, -5.2], [-8.8, 0.8, -11.2]),
        gourmet: viewFrom([3.6, 2.4, -5.2], [8.2, 1.0, -11.8]),
        palmeiras: viewFrom([-2.5, 1.8, 16], [-9.4, 6.5, 5.5])
      }
    },
    apt1: {
      layers: [{ key: 'city' }, { key: 'site' }, { key: 'roofs' }, { key: 'towerA' }, { key: 'towerB' }, { key: 'apt1', own: true }],
      fov: 60, fog: 0.0008, shadowR: 12, indoor: true, ao: { r: 0.32, s: 1.7, sc: 0.0, k: 0.9 },
      lights: [{ p: [2.2, 2.55, 4.8], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [2.2, 2.55, 1.3], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [6.4, 2.55, 4.6], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [6.95, 2.55, 1.4], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [5.25, 2.55, 1.4], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [4, 2.55, 7.3], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }],
      lim: { minD: 0.2, maxD: 45, minP: -0.7, maxP: 1.5, box: null, minEye: -1000 },
      local: true,
      anchors: { sala: [2.0, 1.3, 5.0], cozinha: [2.3, 1.5, 1.2], quarto: [6.6, 1.3, 4.6], banheiro: [6.9, 1.5, 1.5], sacada: [4.2, 1.4, 7.4] },
      views: {
        overview: { t: [4, 0, 4.2], d: 14, yaw: 0.5, pitch: 1.0 },
        sala: viewFrom([4.1, 1.6, 6.2], [0.6, 1.0, 4.2]),
        cozinha: viewFrom([3.9, 1.6, 5.4], [1.6, 0.9, 0.5]),
        quarto: viewFrom([5.0, 1.6, 6.2], [7.6, 0.6, 4.2]),
        banheiro: viewFrom([6.15, 1.65, 2.55], [7.5, 0.8, 0.5]),
        sacada: viewFrom([1.2, 1.6, 6.9], [4.5, -4, 30])
      }
    },
    apt2: {
      layers: [{ key: 'city' }, { key: 'site' }, { key: 'roofs' }, { key: 'towerA' }, { key: 'towerB' }, { key: 'apt2', own: true }],
      fov: 60, fog: 0.0008, shadowR: 13, indoor: true, ao: { r: 0.32, s: 1.7, sc: 0.0, k: 0.9 },
      lights: [{ p: [2.6, 2.55, 5.2], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [2.6, 2.55, 1.4], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [6.8, 2.55, 5.4], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [6.5, 2.55, 1.2], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [8.95, 2.55, 1.2], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [9.2, 2.55, 4.4], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [7.5, 2.55, 3.0], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }, { p: [5, 2.55, 7.8], c: [1.0, 0.7, 0.42], m: 2.2, indoor: true }],
      lim: { minD: 0.2, maxD: 45, minP: -0.7, maxP: 1.5, box: null, minEye: -1000 },
      local: true,
      anchors: { sala: [2.4, 1.3, 5.3], cozinha: [2.5, 1.5, 1.2], suite: [6.9, 1.3, 5.2], quarto2: [6.4, 1.4, 1.3], banheiro: [9.0, 1.6, 1.3], banhoSuite: [9.3, 1.6, 4.4], sacada: [6.0, 1.4, 7.8] },
      views: {
        overview: { t: [5, 0, 4.4], d: 16, yaw: 0.45, pitch: 1.0 },
        sala: viewFrom([4.7, 1.6, 6.6], [0.8, 1.0, 4.4]),
        cozinha: viewFrom([4.6, 1.6, 5.2], [1.8, 0.9, 0.5]),
        suite: viewFrom([8.2, 1.6, 6.7], [5.8, 0.6, 4.6]),
        quarto2: viewFrom([7.6, 1.6, 2.25], [5.6, 0.6, 0.3]),
        banheiro: viewFrom([8.15, 1.65, 2.25], [9.7, 0.8, 0.4]),
        banhoSuite: viewFrom([8.6, 1.65, 5.05], [9.7, 0.8, 3.8]),
        sacada: viewFrom([1.2, 1.6, 7.6], [6, -4, 30])
      }
    }
  };
  this.scenes.deco = {
    layers: [{ key: 'city' }, { key: 'site' }, { key: 'roofs' }, { key: 'towerA' }, { key: 'towerB' }, { key: 'deco', gltf: true, own: true }],
    fov: 62, fog: 0.0008, shadowR: 12, indoor: true, ao: { r: 0.3, s: 1.4, sc: 0.0, k: 0.45 }, lights: [],
    lim: { minD: 0.2, maxD: 45, minP: -0.7, maxP: 1.5, box: null, minEye: -1000 }, local: true,
    anchors: {}, views: { overview: { t: [3.5, 0, 5.3], d: 17, yaw: 0.5, pitch: 1.0 } }
  };
  var self0 = this;
  Object.keys(this.scenes).forEach(function (k) { var L = self0.scenes[k].layers; if (G) { L.push({ key: 'tiles', tiles: true }); L.forEach(function (l) { if (l.key === 'city') l.hidden = true; }); } L.push({ key: 'bridge', points: true }); });
  if (G) { this.tiles = new Tiles(this, G); this.bridgeCfg = opts.bridge || null; this._buildBridge(); }
  if (opts.aptUrl) this._loadDeco(opts.aptUrl, opts.aptViews);
  this.scene = 'site'; this.off = [0, 0, 0];
  this.cam = Object.assign({}, this.scenes.site.views.overview); this.cam.t = this.cam.t.slice();
  this.fade = 1; this.fadeTarget = 1; this.anim = null; this.sel = null; this.hover = null;
  this.autoRotate = true; this.lastInteract = performance.now() - 3000; this.shadowDirty = true;
  this.setTime(9, 22, 15.5);

  /* entrada */
  this.ptrs = new Map(); this.down = null;
  this._on(canvas, 'pointerdown', function (e) { canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId); self.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); self.down = { x: e.clientX, y: e.clientY, btn: e.button, shift: e.shiftKey || e.ctrlKey || e.metaKey, moved: 0 }; self._touch(); });
  this._on(canvas, 'pointermove', function (e) {
    var p = self.ptrs.get(e.pointerId);
    if (!p) { self._hoverAt(e); return; }
    var dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY; if (self.down) self.down.moved += Math.abs(dx) + Math.abs(dy);
    self._touch(); self.anim = null;
    if (self.ptrs.size >= 2) {
      var arr = Array.from(self.ptrs.values()), a = arr[0], b = arr[1], dist = Math.hypot(a.x - b.x, a.y - b.y);
      if (self._pinch) { self._zoom(self._pinch / dist); self._pan(dx * 0.5, dy * 0.5); }
      self._pinch = dist; return;
    }
    if (self.down && (self.down.btn === 2 || self.down.btn === 1 || self.down.shift)) self._pan(dx, dy);
    else { self.cam.yaw -= dx * 0.0055; self.cam.pitch += dy * 0.0045; self._clamp(); }
  });
  var up = function (e) {
    var wasClick = self.down && self.down.moved < 6 && self.ptrs.size === 1 && self.down.btn === 0;
    self.ptrs.delete(e.pointerId); if (self.ptrs.size < 2) self._pinch = null;
    if (wasClick && e.type === 'pointerup') self._clickAt(e);
    if (self.ptrs.size === 0) self.down = null;
  };
  this._on(canvas, 'pointerup', up); this._on(canvas, 'pointercancel', up);
  this._on(canvas, 'pointerleave', function () { if (self.hover) { self.hover = null; canvas.style.cursor = ''; opts.onHover && opts.onHover(null); } });
  this._on(canvas, 'contextmenu', function (e) { e.preventDefault(); });
  this._on(canvas, 'wheel', function (e) { e.preventDefault(); self._touch(); self.anim = null; self._zoom(Math.exp(e.deltaY * (e.deltaMode ? 0.05 : 0.0012))); }, { passive: false });

  this._ro = new ResizeObserver(function () { self._resize(); }); this._ro.observe(canvas); this._resize();
  this.t0 = performance.now(); this._last = this.t0;
  var loop = function (t) { if (self.dead) return; self._frame(t); self.raf = requestAnimationFrame(loop); };
  this.raf = requestAnimationFrame(loop);
}
Engine.prototype = {
  _on: function (el, ev, fn, o) { el.addEventListener(ev, fn, o); (this._ls = this._ls || []).push([el, ev, fn, o]); },
  _vaoPos: function (arr) { var gl = this.gl, vao = gl.createVertexArray(), b = gl.createBuffer(); gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 12, 0); gl.bindVertexArray(null); return { vao: vao, n: arr.length / 3 }; },
  _upload: function (key, geo) {
    var gl = this.gl, arr = geo.array(), vao = gl.createVertexArray(), b = gl.createBuffer();
    gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW);
    var st = 44; gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, st, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, st, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, st, 24);
    gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 2, gl.FLOAT, false, st, 36);
    gl.bindVertexArray(null);
    this.buffers[key] = { vao: vao, n: arr.length / 11 };
  },
  _touch: function () { this.lastInteract = performance.now(); },
  _resize: function () {
    var dpr = Math.min(window.devicePixelRatio || 1, 1.75), w = Math.max(1, Math.round(this.canvas.clientWidth * dpr)), h = Math.max(1, Math.round(this.canvas.clientHeight * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h || (this.postOK && !this.T)) {
      this.canvas.width = w; this.canvas.height = h;
      if (this.postOK) { try { this._targets(w, h); } catch (e) { this._free(); this.postOK = false; } }
    }
  },
  _free: function () {
    var gl = this.gl, T = this.T; if (!T) return;
    Object.keys(T).forEach(function (k) { var o = T[k]; if (!o || typeof o !== 'object') return; if (o instanceof WebGLTexture) gl.deleteTexture(o); else if (o instanceof WebGLFramebuffer) gl.deleteFramebuffer(o); else if (o instanceof WebGLRenderbuffer) gl.deleteRenderbuffer(o); });
    this.T = null;
  },
  _targets: function (w, h) {
    var gl = this.gl; this._free();
    var CF = this.hdr ? gl.RGBA16F : gl.RGBA8, T = { w: w, h: h };
    function tex(tw, th, f, filt) { var t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t); gl.texStorage2D(gl.TEXTURE_2D, 1, f, tw, th); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filt); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filt); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); return t; }
    function fbo(c, d) { var f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f); if (c) gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, c, 0); if (d) gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, d, 0); if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('fbo'); return f; }
    this.T = T;
    T.sC = tex(w, h, CF, gl.LINEAR); T.sD = tex(w, h, gl.DEPTH_COMPONENT24, gl.NEAREST); T.sF = fbo(T.sC, T.sD);
    try {
      var ns = Math.min(4, gl.getParameter(gl.MAX_SAMPLES));
      if (ns > 1) {
        T.mC = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, T.mC); gl.renderbufferStorageMultisample(gl.RENDERBUFFER, ns, CF, w, h);
        T.mD = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, T.mD); gl.renderbufferStorageMultisample(gl.RENDERBUFFER, ns, gl.DEPTH_COMPONENT24, w, h);
        T.mF = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, T.mF);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, T.mC); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, T.mD);
        if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) { gl.deleteFramebuffer(T.mF); T.mF = null; }
      }
    } catch (e) { T.mF = null; }
    T.hw = Math.max(1, w >> 1); T.hh = Math.max(1, h >> 1); T.qw = Math.max(1, w >> 2); T.qh = Math.max(1, h >> 2);
    T.a1 = tex(T.hw, T.hh, gl.RGBA8, gl.LINEAR); T.a1F = fbo(T.a1); T.a2 = tex(T.hw, T.hh, gl.RGBA8, gl.LINEAR); T.a2F = fbo(T.a2);
    T.b1 = tex(T.qw, T.qh, CF, gl.LINEAR); T.b1F = fbo(T.b1); T.b2 = tex(T.qw, T.qh, CF, gl.LINEAR); T.b2F = fbo(T.b2);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  },
  _sc: function () { return this.scenes[this.scene]; },
  _clamp: function () {
    var L = this._sc().lim, c = this.cam;
    c.pitch = clamp(c.pitch, L.minP, L.maxP); c.d = clamp(c.d, L.minD, L.maxD);
    if (L.box) { c.t[0] = clamp(c.t[0], L.box[0], L.box[1]); c.t[2] = clamp(c.t[2], L.box[2], L.box[3]); c.t[1] = clamp(c.t[1], 0, 120); }
  },
  _zoom: function (f) { this.cam.d *= f; this._clamp(); },
  _pan: function (dx, dy) {
    var c = this.cam, s = c.d * 0.0016 * (this._sc().fov / 42);
    var rx = Math.cos(c.yaw), rz = -Math.sin(c.yaw), fx = -Math.sin(c.yaw), fz = -Math.cos(c.yaw);
    if (c.pitch > 0.9) { c.t[0] -= (rx * dx - fx * dy) * s; c.t[2] -= (rz * dx - fz * dy) * s; }
    else { c.t[0] -= rx * dx * s; c.t[2] -= rz * dx * s; c.t[1] += dy * s; }
    this._clamp();
  },
  eye: function () { var c = this.cam, cp = Math.cos(c.pitch); var e = [c.t[0] + c.d * cp * Math.sin(c.yaw), c.t[1] + c.d * Math.sin(c.pitch), c.t[2] + c.d * cp * Math.cos(c.yaw)]; var m = this._sc().lim.minEye; if (e[1] < m) e[1] = m; return e; },
  _matrices: function () {
    var W = this.canvas.width, H = this.canvas.height, sc = this._sc();
    var e = this.eye(); var near = sc.indoor ? 0.08 : 0.5, far = sc.indoor ? 2500 : 3000;
    var V = M4.lookAt(e, this.cam.t, [0, 1, 0]), Pm = M4.persp(sc.fov * PI / 180, W / H, near, far);
    this.Pm = Pm; this.IPm = M4.inv(Pm); this.VP = M4.mul(Pm, V); this.IVP = M4.inv(this.VP); this.E = e;
  },
  setTime: function (month, day, hour) {
    var s = sunInfo(month, day, hour); this.sun = s; this.shadowDirty = true; this._tm = [month, day, hour];
    var sdir = this.frame ? this.frame.dirToSite(s.dir) : s.dir; this.sunDir = sdir;
    var el = s.elev, day1 = sstep(-7, 10, el), dusk = clamp(1 - Math.abs(el - 3) / 11, 0, 1) * sstep(-8, 0, el);
    var sunAmt = sstep(-1.5, 6, el);
    this.L = {
      dir: el > -1.5 ? sdir : [0.3, 0.8, 0.5], day: day1, dusk: dusk,
      sunC: mix3(mix3([1.0, 0.45, 0.2], [1.0, 0.95, 0.88], sstep(2, 28, el)), [0, 0, 0], 1 - sunAmt).map(function (v) { return v * 2.7; }),
      sky: mix3([0.03, 0.04, 0.08], [0.42, 0.52, 0.72], day1),
      gnd: mix3([0.02, 0.02, 0.03], [0.27, 0.24, 0.21], day1),
      zen: mix3(mix3([0.01, 0.015, 0.04], [0.12, 0.33, 0.75], day1), [0.25, 0.25, 0.45], dusk * 0.5),
      hor: mix3(mix3([0.04, 0.05, 0.1], [0.68, 0.8, 0.93], day1), [1.0, 0.55, 0.32], dusk * 0.7),
      emis: 0.8 + 2.0 * (1 - day1), night: 1 - day1, shadowOn: sunAmt > 0.02
    };
    return { elev: el, az: s.az, rise: s.rise, set: s.set, noon: s.noon };
  },
  go: function (scene, view, dur) {
    var self = this, sc = this.scenes[scene]; if (!sc) return;
    var v = typeof view === 'string' ? sc.views[view] : view; if (!v) return;
    var tgt = { t: v.t.slice(), d: v.d, yaw: v.yaw, pitch: v.pitch };
    if (sc.local) tgt.t = add3(tgt.t, this.off);
    dur = dur == null ? 1400 : dur;
    if (scene !== this.scene) {
      this.fadeTarget = 0;
      clearTimeout(this._swapT);
      this._swapT = setTimeout(function () { self.scene = scene; self.shadowDirty = true; self.cam = tgt; self.anim = null; self.fadeTarget = 1; self.sel = scene === 'site' ? self.sel : null; }, 260);
    } else {
      var from = { t: this.cam.t.slice(), d: this.cam.d, yaw: this.cam.yaw, pitch: this.cam.pitch };
      var dy = tgt.yaw - from.yaw; dy = ((dy + PI) % (2 * PI) + 2 * PI) % (2 * PI) - PI; tgt.yaw = from.yaw + dy;
      this.anim = { from: from, to: tgt, t0: performance.now(), dur: dur };
    }
    this._touch();
  },
  setLayer: function (scene, key, vis) { this.scenes[scene].layers.forEach(function (l) { if (l.key === key) l.hidden = !vis; }); this.shadowDirty = true; },
  /* posiciona o apartamento-tipo no local real da unidade */
  placeInterior: function (type, unitId) {
    var m = /^([AB])-(\d+)(0[12])$/.exec(unitId || '') || ['', 'A', '10', type === 'apt1' ? '01' : '02'];
    var tw = m[1], f = parseInt(m[2], 10), fin = m[3];
    var ox = TOWER.X[tw], ux = UNITX[fin], D = type === 'apt1' ? 6.5 : 7;
    this.off = [ox + ux[0], floorBase(f) + 0.16, TOWER.D / 2 - D];
    if (type === 'deco') { var dz = this.decoSize || [7.05, 2.5, 10.66]; this.off = [ox + (ux[0] + ux[1]) / 2 - dz[0] / 2, floorBase(f) + 0.16, TOWER.D / 2 - dz[2]]; }
    var sc = this.scenes[type];
    sc.layers.forEach(function (l) { if (l.key === 'towerA') l.hidden = tw === 'A'; if (l.key === 'towerB') l.hidden = tw === 'B'; if (l.own) l.off = null; });
    sc.lim.minEye = this.off[1] - 0.2 - 200;
    sc.shadowC = add3(this.off, [5, 1, 4]);
    return this.off;
  },
  select: function (id) { this.sel = id ? this._pickBox(id) : null; },
  _pickBox: function (id) { for (var i = 0; i < this.picks.length; i++) if (this.picks[i].id === id) return this.picks[i]; return null; },
  unitView: function (id) {
    var b = this._pickBox(id) || { min: [-20, 30, -6], max: [-12, 33, 8] };
    var cx = (b.min[0] + b.max[0]) / 2, cy = (b.min[1] + b.max[1]) / 2;
    return { t: [cx, cy, 6], d: 46, yaw: cx < 0 ? -0.32 : 0.32, pitch: 0.1 };
  },
  anchor: function (scene, key) { var sc = this.scenes[scene], a = sc && sc.anchors[key]; if (!a) return null; return sc.local ? add3(a, this.off) : a; },
  project: function (p) {
    if (!this.VP) return null; var c = M4.xf(this.VP, p[0], p[1], p[2], 1); if (c[3] <= 0.05) return null;
    var x = c[0] / c[3], y = c[1] / c[3]; if (x < -1.2 || x > 1.2 || y < -1.2 || y > 1.2) return null;
    return { x: (x * 0.5 + 0.5) * this.canvas.clientWidth, y: (0.5 - y * 0.5) * this.canvas.clientHeight, dist: c[3] };
  },
  _ray: function (e) {
    var r = this.canvas.getBoundingClientRect(), nx = (e.clientX - r.left) / r.width * 2 - 1, ny = 1 - (e.clientY - r.top) / r.height * 2;
    var a = M4.xf(this.IVP, nx, ny, -1, 1), b = M4.xf(this.IVP, nx, ny, 1, 1);
    a = [a[0] / a[3], a[1] / a[3], a[2] / a[3]]; b = [b[0] / b[3], b[1] / b[3], b[2] / b[3]];
    var d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], l = Math.hypot(d[0], d[1], d[2]); return { o: a, d: [d[0] / l, d[1] / l, d[2] / l] };
  },
  _pick: function (e) {
    if (this.scene !== 'site' || !this.IVP) return null;
    var ray = this._ray(e), best = null, bt = 1e9;
    for (var i = 0; i < this.picks.length; i++) {
      var b = this.picks[i], t0 = -1e9, t1 = 1e9, ok = true;
      for (var k = 0; k < 3; k++) {
        if (Math.abs(ray.d[k]) < 1e-9) { if (ray.o[k] < b.min[k] || ray.o[k] > b.max[k]) { ok = false; break; } continue; }
        var ta = (b.min[k] - ray.o[k]) / ray.d[k], tb = (b.max[k] - ray.o[k]) / ray.d[k]; if (ta > tb) { var tt = ta; ta = tb; tb = tt; }
        t0 = Math.max(t0, ta); t1 = Math.min(t1, tb); if (t0 > t1) { ok = false; break; }
      }
      if (ok && t1 > 0 && t0 < bt) { bt = t0; best = b; }
    }
    /* ignora se a torre (opaca) está na frente: teste simples contra os corpos das torres */
    if (best) {
      var bodies = [[TOWER.X.A - 11, 0, -6.5, TOWER.X.A + 11, 52, 6.5], [TOWER.X.B - 11, 0, -6.5, TOWER.X.B + 11, 52, 6.5]];
      for (var j = 0; j < 2; j++) {
        var B = bodies[j], s0 = -1e9, s1 = 1e9, hit = true;
        for (var q = 0; q < 3; q++) { var mn = B[q], mx = B[q + 3]; if (Math.abs(ray.d[q]) < 1e-9) { if (ray.o[q] < mn || ray.o[q] > mx) { hit = false; break; } continue; } var u0 = (mn - ray.o[q]) / ray.d[q], u1 = (mx - ray.o[q]) / ray.d[q]; if (u0 > u1) { var w = u0; u0 = u1; u1 = w; } s0 = Math.max(s0, u0); s1 = Math.min(s1, u1); if (s0 > s1) { hit = false; break; } }
        if (hit && s0 > 0 && s0 < bt - 0.8 && !(best.min[0] >= B[0] - 0.1 && best.max[0] <= B[3] + 0.1)) return null;
      }
    }
    return best;
  },
  _hoverAt: function (e) {
    var now = performance.now(); if (this._lh && now - this._lh < 40) return; this._lh = now;
    var b = this._pick(e), id = b ? b.id : null;
    if (id !== (this.hover && this.hover.id)) { this.hover = b; this.canvas.style.cursor = b ? 'pointer' : ''; this.opts.onHover && this.opts.onHover(id); }
  },
  _clickAt: function (e) { var b = this._pick(e); this.opts.onPick && this.opts.onPick(b ? b.id : null); },
  _drawLayers: function (depth) {
    var gl = this.gl, sc = this._sc(), pr = depth ? this.PD : this.P, self = this;
    sc.layers.forEach(function (l) {
      if (l.hidden || l.tiles || l.gltf || l.points) return; var b = self.buffers[l.key]; if (!b) return;
      if (depth && l.key === 'city' && sc.indoor) return;
      var off = l.own ? self.off : [0, 0, 0];
      gl.uniform3fv(pr.u.uOff, off); gl.bindVertexArray(b.vao); gl.drawArrays(gl.TRIANGLES, 0, b.n);
    });
  },
  _frame: function (t) {
    var gl = this.gl, dt = Math.min(0.05, (t - this._last) / 1000); this._last = t;
    var sc = this._sc(), L = this.L;
    /* animação de câmera */
    if (this.anim) {
      var a = this.anim, k = clamp((t - a.t0) / a.dur, 0, 1), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      this.cam = { t: mix3(a.from.t, a.to.t, e), d: a.from.d * Math.pow(a.to.d / a.from.d, e), yaw: a.from.yaw + (a.to.yaw - a.from.yaw) * e, pitch: a.from.pitch + (a.to.pitch - a.from.pitch) * e };
      if (k >= 1) this.anim = null;
    } else if (this.autoRotate && this.scene === 'site' && t - this.lastInteract > 6000 && !this.sel) { this.cam.yaw += dt * 0.045; }
    this.fade += (this.fadeTarget - this.fade) * Math.min(1, dt * 9);
    this._resize(); this._matrices();
    if (this.tiles) { this._planes(); this.tiles.update(this.E, this.planesArr, this.canvas.height, sc.fov * PI / 180); if (this.tiles.drawn.length && this.tiles.frame % 20 === 0) this.shadowDirty = true; }
    /* sombra */
    var R = sc.shadowR, ctr = sc.shadowC || [0, 20, 0], d = L.dir;
    var up = Math.abs(d[1]) > 0.98 ? [0, 0, 1] : [0, 1, 0];
    var LV = M4.lookAt([ctr[0] + d[0] * R * 2.5, ctr[1] + d[1] * R * 2.5, ctr[2] + d[2] * R * 2.5], ctr, up);
    var LVP = M4.mul(M4.ortho(-R, R, -R, R, 0.5, R * 6), LV);
    if (this.shadowDirty && L.shadowOn) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.shFbo); gl.viewport(0, 0, this.SM, this.SM);
      gl.enable(gl.DEPTH_TEST); gl.depthMask(true); gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1.5, 3);
      gl.useProgram(this.PD.p); gl.uniformMatrix4fv(this.PD.u.uLVP, false, LVP);
      this._drawLayers(true);
      this._drawTex(true, LVP);
      gl.disable(gl.POLYGON_OFFSET_FILL); gl.bindFramebuffer(gl.FRAMEBUFFER, null); this.shadowDirty = false;
    }
    var T = this.postOK ? this.T : null, hdr = !!(T && this.hdr), W = this.canvas.width, Hh = this.canvas.height;
    gl.bindFramebuffer(gl.FRAMEBUFFER, T ? (T.mF || T.sF) : null);
    gl.viewport(0, 0, W, Hh);
    gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    var fadeIn = T ? 1 : this.fade, time = (t - this.t0) / 1000;
    /* céu */
    gl.disable(gl.DEPTH_TEST); gl.useProgram(this.PS.p); var u = this.PS.u;
    gl.uniformMatrix4fv(u.uIVP, false, this.IVP); gl.uniform3fv(u.uEye, this.E); gl.uniform3fv(u.uSun, this.sunDir); gl.uniform3fv(u.uZen, L.zen); gl.uniform3fv(u.uHor, L.hor);
    gl.uniform3fv(u.uSunC, L.shadowOn ? L.sunC : [0, 0, 0]); gl.uniform1f(u.uNight, L.night); gl.uniform1f(u.uFade, fadeIn); gl.uniform1f(u.uHdr, hdr ? 1 : 0); gl.uniform1f(u.uTime, time);
    gl.bindVertexArray(this.vaoSky); gl.drawArrays(gl.TRIANGLES, 0, 3);
    /* cena */
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.useProgram(this.P.p); u = this.P.u;
    gl.uniformMatrix4fv(u.uVP, false, this.VP); gl.uniformMatrix4fv(u.uLVP, false, LVP);
    gl.uniform3fv(u.uSun, L.dir); gl.uniform3fv(u.uSunC, L.sunC);
    var sky = L.sky, gnd = L.gnd;
    if (sc.indoor) { var warm = [0.3, 0.25, 0.2]; sky = mix3(sky, warm, L.night * 0.7); gnd = mix3(gnd, [0.2, 0.17, 0.13], L.night * 0.7); sky = [sky[0] * 1.15 + 0.04, sky[1] * 1.15 + 0.04, sky[2] * 1.15 + 0.04]; }
    gl.uniform3fv(u.uSky, sky); gl.uniform3fv(u.uGnd, gnd); gl.uniform3fv(u.uFogC, mix3(L.hor, L.zen, 0.15)); gl.uniform3fv(u.uEye, this.E);
    gl.uniform3fv(u.uZen, L.zen); gl.uniform3fv(u.uHor, L.hor);
    gl.uniform1f(u.uFog, sc.fog); gl.uniform1f(u.uEmis, L.emis); gl.uniform1f(u.uTime, time); gl.uniform1f(u.uFade, fadeIn); gl.uniform1f(u.uHdr, hdr ? 1 : 0);
    gl.uniform1f(u.uShOn, L.shadowOn ? 1 : 0); gl.uniform1f(u.uTex, (0.00025 * (R / 70) + 0.0002) * (2048 / this.SM) * 1.4); gl.uniform1f(u.uSMs, this.SM);
    /* luzes pontuais */
    var Ls = sc.lights || [], nL = Math.min(12, Ls.length), lp = this._lp, lc = this._lc;
    for (var li = 0; li < nL; li++) {
      var Lt = Ls[li], pp = sc.local ? add3(Lt.p, this.off) : Lt.p, f = (Lt.indoor ? 0.15 + 0.85 * L.night : L.night) * Lt.m;
      lp[li * 3] = pp[0]; lp[li * 3 + 1] = pp[1]; lp[li * 3 + 2] = pp[2]; lc[li * 3] = Lt.c[0] * f; lc[li * 3 + 1] = Lt.c[1] * f; lc[li * 3 + 2] = Lt.c[2] * f;
    }
    gl.uniform3fv(u['uPLp[0]'], lp); gl.uniform3fv(u['uPLc[0]'], lc); gl.uniform1i(u.uPLn, nL);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.shTex); gl.uniform1i(u.uSh, 0);
    this._drawLayers(false);
    this._drawTex(false, LVP, hdr, fadeIn);
    this._drawPoints(hdr);
    /* destaques */
    if (this.scene === 'site' && (this.sel || this.hover)) {
      gl.useProgram(this.PO.p); u = this.PO.u; gl.uniformMatrix4fv(u.uVP, false, this.VP);
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
      var hb = hdr ? 1.7 : 1;
      var drawBox = function (b, pad, fill, line) {
        gl.uniform3fv(u.uMin, [b.min[0] - pad, b.min[1] - pad, b.min[2] - pad]); gl.uniform3fv(u.uMax, [b.max[0] + pad, b.max[1] + pad, b.max[2] + pad]);
        gl.uniform4fv(u.uCol, [fill[0] * hb, fill[1] * hb, fill[2] * hb, fill[3]]); gl.bindVertexArray(this.cubeVao.vao); gl.drawArrays(gl.TRIANGLES, 0, this.cubeVao.n);
        gl.uniform4fv(u.uCol, [line[0] * hb, line[1] * hb, line[2] * hb, line[3]]); gl.bindVertexArray(this.edgeVao.vao); gl.drawArrays(gl.LINES, 0, this.edgeVao.n);
      }.bind(this);
      if (this.hover && this.hover !== this.sel) drawBox(this.hover, 0.12, [1, 1, 1, 0.16], [1, 1, 1, 0.8]);
      if (this.sel) { var pulse = 0.28 + 0.12 * Math.sin(t / 260); drawBox(this.sel, 0.2, [0.84, 0.95, 0.36, pulse], [0.84, 0.95, 0.36, 1]); }
      gl.depthMask(true); gl.disable(gl.BLEND);
    }
    /* pós-processamento */
    if (T) {
      if (T.mF) { gl.bindFramebuffer(gl.READ_FRAMEBUFFER, T.mF); gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, T.sF); gl.blitFramebuffer(0, 0, W, Hh, 0, 0, W, Hh, gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT, gl.NEAREST); gl.bindFramebuffer(gl.READ_FRAMEBUFFER, null); }
      gl.disable(gl.DEPTH_TEST); gl.bindVertexArray(this.vaoSky);
      var PP = this.PP, ao = sc.ao || { r: 0.6, s: 1.5, sc: 0.02, k: 0.8 };
      gl.bindFramebuffer(gl.FRAMEBUFFER, T.a1F); gl.viewport(0, 0, T.hw, T.hh); gl.useProgram(PP.ao.p); u = PP.ao.u;
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.sD); gl.uniform1i(u.uDepth, 0);
      gl.uniformMatrix4fv(u.uP, false, this.Pm); gl.uniformMatrix4fv(u.uIP, false, this.IPm); gl.uniform3fv(u['uK[0]'], this.kernel);
      gl.uniform1f(u.uR, ao.r); gl.uniform1f(u.uStr, ao.s); gl.uniform1f(u.uScale, ao.sc); gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindFramebuffer(gl.FRAMEBUFFER, T.a2F); gl.useProgram(PP.aob.p); u = PP.aob.u; gl.bindTexture(gl.TEXTURE_2D, T.a1); gl.uniform1i(u.uT, 0); gl.uniform2f(u.uTx, 1 / T.hw, 1 / T.hh); gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindFramebuffer(gl.FRAMEBUFFER, T.b1F); gl.viewport(0, 0, T.qw, T.qh); gl.useProgram(PP.br.p); u = PP.br.u; gl.bindTexture(gl.TEXTURE_2D, T.sC); gl.uniform1i(u.uT, 0); gl.uniform1f(u.uTh, hdr ? 1.5 : 0.85); gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.useProgram(PP.bl.p); u = PP.bl.u; gl.uniform1i(u.uT, 0);
      for (var bi = 0; bi < 2; bi++) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, T.b2F); gl.bindTexture(gl.TEXTURE_2D, T.b1); gl.uniform2f(u.uDir, 1 / T.qw, 0); gl.drawArrays(gl.TRIANGLES, 0, 3);
        gl.bindFramebuffer(gl.FRAMEBUFFER, T.b1F); gl.bindTexture(gl.TEXTURE_2D, T.b2); gl.uniform2f(u.uDir, 0, 1 / T.qh); gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, W, Hh); gl.useProgram(PP.cp.p); u = PP.cp.u;
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.sC); gl.uniform1i(u.uS, 0);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, T.a2); gl.uniform1i(u.uA, 1);
      gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, T.b1); gl.uniform1i(u.uB, 2);
      gl.uniform1f(u.uFade, this.fade); gl.uniform1f(u.uAOs, ao.k); gl.uniform1f(u.uBl, hdr ? 0.35 + 0.2 * L.night : 0.3); gl.uniform1f(u.uHdr, hdr ? 1 : 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3); gl.activeTexture(gl.TEXTURE0);
    }
    gl.bindVertexArray(null);
    if (this.opts.onFrame) this.opts.onFrame(this);
  },
  _planes: function () {
    var m = this.VP, P = [];
    var rows = [[m[3] + m[0], m[7] + m[4], m[11] + m[8], m[15] + m[12]], [m[3] - m[0], m[7] - m[4], m[11] - m[8], m[15] - m[12]], [m[3] + m[1], m[7] + m[5], m[11] + m[9], m[15] + m[13]], [m[3] - m[1], m[7] - m[5], m[11] - m[9], m[15] - m[13]], [m[3] + m[2], m[7] + m[6], m[11] + m[10], m[15] + m[14]], [m[3] - m[2], m[7] - m[6], m[11] - m[10], m[15] - m[14]]];
    rows.forEach(function (r) { var l = Math.hypot(r[0], r[1], r[2]); P.push([r[0] / l, r[1] / l, r[2] / l, r[3] / l]); });
    this.planesArr = P;
  },
  _tilesFailed: function (msg) {
    var self = this; Object.keys(this.scenes).forEach(function (k) { self.scenes[k].layers.forEach(function (l) { if (l.key === 'city') l.hidden = false; if (l.tiles) l.hidden = true; }); });
    this.clip = null; this.opts.onStatus && this.opts.onStatus('erro', msg);
  },
  _buildBridge: function () {
    var gl = this.gl; if (!this.frame || !this.bridgeCfg) return;
    var b = bridgePoints(this.frame, this.bridgeCfg); this.bridgeInfo = b;
    if (!this.bvao) { this.bvao = gl.createVertexArray(); this.bbuf = gl.createBuffer(); }
    gl.bindVertexArray(this.bvao); gl.bindBuffer(gl.ARRAY_BUFFER, this.bbuf); gl.bufferData(gl.ARRAY_BUFFER, b.data, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 24, 0); gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 24, 12);
    gl.disableVertexAttribArray(2); gl.disableVertexAttribArray(3); gl.bindVertexArray(null); this.bcount = b.data.length / 6;
  },
  setBridge: function (cfg) { this.bridgeCfg = cfg; this._buildBridge(); },
  setSite: function (lat, lon, h, heading) {
    if (!this.frame) return; this.frame.set(lat, lon, h, heading); this.shadowDirty = true; this._buildBridge();
    if (this._tm) this.setTime(this._tm[0], this._tm[1], this._tm[2]);
  },
  pickTiles: function (cx, cy) { if (!this.tiles || !this.IVP) return null; var r = this._ray({ clientX: cx, clientY: cy }); return this.tiles.raycast(r.o, r.d); },
  /* estima a altura do chão em volta do lote (para encaixar o terreno no relevo real) */
  probeGround: function () {
    if (!this.tiles) return null; var hs = [], c = this.clip || [-41, 41, -21, 24.5];
    for (var i = 0; i < 16; i++) { var a = i / 16 * 2 * PI, x = Math.cos(a) * 52, z = Math.sin(a) * 34 + 1.5; var hit = this.tiles.raycast([x, 400, z], [0, -1, 0]); if (hit) hs.push(hit[1]); }
    if (hs.length < 4) return null; hs.sort(function (a, b) { return a - b; }); return hs[Math.floor(hs.length * 0.3)];
  },
  _loadDeco: function (url, views) {
    var self = this, gl = this.gl;
    fetch(url).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); }).then(function (ab) { return loadGltf(ab, { base: url }); }).then(function (g) { return uploadPrims(gl, g.prims); }).then(function (ps) {
      var mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      ps.forEach(function (p) { for (var i = 0; i < p.pos.length; i += 3) { var w = D4.pt(p.matrix, p.pos[i], p.pos[i + 1], p.pos[i + 2]); for (var k = 0; k < 3; k++) { if (w[k] < mn[k]) mn[k] = w[k]; if (w[k] > mx[k]) mx[k] = w[k]; } } });
      var sh = new Float64Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, -mn[0], -mn[1], -mn[2], 1]);
      ps.forEach(function (p) { p.local = D4.mul(sh, p.matrix); });
      self.deco = ps; self.decoSize = [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]];
      if (views) { Object.keys(views.views || {}).forEach(function (k) { var v = views.views[k]; self.scenes.deco.views[k] = v.E ? viewFrom(v.E, v.T) : v; }); self.scenes.deco.anchors = views.anchors || {}; self.scenes.deco.lights = views.lights || []; }
      self.opts.onDeco && self.opts.onDeco(true);
    }).catch(function (e) { self.decoErr = String(e && e.message || e); self.opts.onDeco && self.opts.onDeco(false, self.decoErr); });
  },
  _drawTex: function (depth, LVP, hdr, fade) {
    var gl = this.gl, sc = this._sc(), self = this, hasTiles = false, hasDeco = false;
    sc.layers.forEach(function (l) { if (l.hidden) return; if (l.tiles && self.tiles) hasTiles = true; if (l.gltf && self.deco && sc === self._sc()) hasDeco = true; });
    if (!hasTiles && !hasDeco) return;
    var pr = depth ? this.PDM : this.PT, u = pr.u, L = this.L; gl.useProgram(pr.p);
    var clip = this.clip;
    if (depth) { gl.uniformMatrix4fv(u.uLVP, false, LVP); }
    else {
      gl.uniformMatrix4fv(u.uVP, false, this.VP); gl.uniformMatrix4fv(u.uLVP, false, LVP);
      gl.uniform3fv(u.uSun, this.L.dir); gl.uniform3fv(u.uFogC, mix3(L.hor, L.zen, 0.15)); gl.uniform3fv(u.uEye, this.E);
      var tint = mix3([1, 1, 1], [1.15, 0.82, 0.62], L.dusk * 0.8); gl.uniform3fv(u.uTint, tint);
      gl.uniform1f(u.uNight, clamp(L.night * 1.1, 0, 1)); gl.uniform1f(u.uFog, sc.fog); gl.uniform1f(u.uShOn, L.shadowOn ? 1 : 0); gl.uniform1f(u.uSMs, this.SM);
      gl.uniform1f(u.uBias, (0.00025 * (sc.shadowR / 70) + 0.0002) * (2048 / this.SM) * 1.4); gl.uniform1f(u.uHdr, hdr ? 1 : 0); gl.uniform1f(u.uFade, fade);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.shTex); gl.uniform1i(u.uSh, 1); gl.uniform1i(u.uTx, 0); gl.activeTexture(gl.TEXTURE0);
    }
    if (hasTiles) {
      if (clip) { gl.uniform4f(u.uClip, clip[0], clip[1], clip[2], clip[3]); gl.uniform1f(u.uClipOn, 1); } else gl.uniform1f(u.uClipOn, 0);
      if (!depth) { gl.uniform1f(u.uMode, 0); gl.uniform1f(u.uK, hdr ? 1.25 : 1.0); }
      this.tiles.each(function (p) {
        gl.uniformMatrix4fv(u.uModel, false, p.site32);
        if (!depth) { gl.uniform4fv(u.uUvT, p.uvT); gl.uniform4fv(u.uCol, p.color); gl.uniform1f(u.uHasTex, p.tex ? 1 : 0); if (p.tex) gl.bindTexture(gl.TEXTURE_2D, p.tex); }
        gl.bindVertexArray(p.vao); if (p.it) gl.drawElements(gl.TRIANGLES, p.cnt, p.it, 0); else gl.drawArrays(gl.TRIANGLES, 0, p.cnt);
      });
    }
    if (hasDeco && !depth) {
      gl.uniform1f(u.uClipOn, 0); gl.uniform1f(u.uMode, 1); gl.uniform1f(u.uK, hdr ? 1.35 : 1.0);
      var off = this.off, top = this.E[1] > off[1] + 2.3;
      this.deco.forEach(function (p) {
        if (top && /teto|ceil/i.test(p.name)) return;
        var m = D4.mul(new Float64Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, off[0], off[1], off[2], 1]), p.local);
        gl.uniformMatrix4fv(u.uModel, false, new Float32Array(m)); gl.uniform4fv(u.uUvT, p.uvT); gl.uniform4fv(u.uCol, p.color); gl.uniform1f(u.uHasTex, p.tex ? 1 : 0); if (p.tex) gl.bindTexture(gl.TEXTURE_2D, p.tex);
        gl.bindVertexArray(p.vao); if (p.it) gl.drawElements(gl.TRIANGLES, p.cnt, p.it, 0); else gl.drawArrays(gl.TRIANGLES, 0, p.cnt);
      });
    }
    gl.bindVertexArray(null);
  },
  _drawPoints: function (hdr) {
    var gl = this.gl; if (!this.bvao || !this.bcount || this.L.night < 0.05) return;
    var sc = this._sc(); if (!sc.layers.some(function (l) { return l.points && !l.hidden; })) return;
    gl.useProgram(this.PPT.p); var u = this.PPT.u; gl.uniformMatrix4fv(u.uVP, false, this.VP);
    var tw = 0.85 + 0.15 * Math.sin(performance.now() / 900);
    gl.uniform1f(u.uS, 900 * Math.min(window.devicePixelRatio || 1, 1.75)); gl.uniform1f(u.uI, (hdr ? 7 : 1.4) * this.L.night * tw);
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE); gl.depthMask(false);
    gl.bindVertexArray(this.bvao); gl.drawArrays(gl.POINTS, 0, this.bcount); gl.bindVertexArray(null);
    gl.depthMask(true); gl.disable(gl.BLEND);
  },
  destroy: function () {
    this.dead = true; cancelAnimationFrame(this.raf); this._free(); clearTimeout(this._swapT); if (this._ro) this._ro.disconnect();
    (this._ls || []).forEach(function (l) { l[0].removeEventListener(l[1], l[2], l[3]); });
  }
};
Engine.sun = sunInfo; Engine.geo2ecef = geo2ecef; Engine.ecef2geo = ecef2geo;
window.VistaEngine = Engine;
})();
